import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Book } from "src/app/model/book.model";
import { Wishlist } from "src/app/model/wishlist.model";
import { UserService } from "./user.service";

@Injectable({
  providedIn: "root",
})
export class WishlistService {
  constructor(private http: HttpClient, private userService: UserService) {}

  backendUrl: string = "http://localhost:7000/wishlist";

  getUserWishlists(userId: string = null) {
    let loggedInUserId = this.userService.getLoggedInUserId();
    return this.http.get(
      this.backendUrl + "/" + (userId ? userId : loggedInUserId)
    );
  }

  create(wishlist: Wishlist) {
    let loggedInUserId = this.userService.getLoggedInUserId();
    wishlist.userId = loggedInUserId;
    let body = { data: wishlist, userId: loggedInUserId };
    delete body.data._id;
    return this.http.post(this.backendUrl, body);
  }

  delete(wishlistId: string) {
    let loggedInUserId = this.userService.getLoggedInUserId();
    return this.http.delete(
      this.backendUrl +
        "/?wishlistId=" +
        wishlistId +
        "&userId=" +
        loggedInUserId
    );
  }

  addToWishlist(wishlistId: string, book: Book) {
    let userId = this.userService.getLoggedInUserId();
    let body = {
      data: {
        _id: book._id,
        title: book.title,
        available: book.available,
        amount: book.amount,
        cover: book.cover,
        authors: book.authors,
        price: book.price,
      },
      userId: userId,
    };
    return this.http.patch(this.backendUrl + "/add/" + wishlistId, body);
  }

  deleteFromWishlist(wishlistId: string, bookId: string) {
    let userId = this.userService.getLoggedInUserId();
    let body = { bookId: bookId, userId: userId };
    return this.http.patch(this.backendUrl + "/remove/" + wishlistId, body);
  }
}
