import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Book } from "src/app/model/book.model";
import { UserService } from "./user.service";

@Injectable({
  providedIn: "root",
})
export class BookService {
  constructor(private http: HttpClient, private userService: UserService) {}

  backendUrl: string = "http://localhost:7000/book";

  allCategories = [
    "fiction",
    "classic",
    "political",
    "adventure",
    "historical adventure",
    "historical fiction",
    "horror",
    "crime",
    "children",
    "comedy",
    "thriller",
    "drama",
    "romance",
    "contemporary fiction",
    "sci-fi",
    "fantasy",
    "mystery",
  ];

  createBook(newBook: Book, userId: string, coverImage: string | ArrayBuffer) {
    let body = {
      data: JSON.parse(JSON.stringify(newBook)),
      userId: userId,
      coverImage: coverImage,
    };
    delete body.data._id;
    return this.http.post(this.backendUrl, body);
  }

  getBestSellingBooks() {
    return this.http.get(this.backendUrl + "/best-selling");
  }

  getFiltered(params: any, page: number = 1) {
    let parameters = "";
    if (params) {
      parameters =
        "&author=" +
        params.author +
        "&category=" +
        params.category +
        "&search=" +
        params.search;
    }
    return this.http.get(this.backendUrl + "/?page=" + page + parameters);
  }

  update(bookId: string, book: Book, coverImage: string | ArrayBuffer) {
    let userId = this.userService.getLoggedInUserId();
    let body = {
      data: JSON.parse(JSON.stringify(book)),
      userId: userId,
      coverImage: coverImage,
    };
    delete body.data._id;
    return this.http.patch(this.backendUrl + "/" + bookId, body);
  }

  getById(bookId: string) {
    return this.http.get(this.backendUrl + "/" + bookId);
  }

  delete(bookId: string) {
    return this.http.delete(this.backendUrl + "/" + bookId);
  }
}
