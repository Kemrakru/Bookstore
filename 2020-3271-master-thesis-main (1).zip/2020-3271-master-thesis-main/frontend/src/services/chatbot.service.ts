import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class ChatbotService {
  constructor(private http: HttpClient) {}

  backendUrl: string = "http://localhost:7000/chatbot";

  getChatbotAnswer(userMsg: string) {
    let body = { language: "en-US", message: userMsg };
    return this.http.post(this.backendUrl, body);
  }
}
