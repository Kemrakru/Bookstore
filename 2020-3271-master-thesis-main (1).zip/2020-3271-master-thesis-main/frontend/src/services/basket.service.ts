import { Injectable } from "@angular/core";
import { Book } from "src/app/model/book.model";

@Injectable({
  providedIn: "root",
})
export class BasketService {
  constructor() {}

  addToBasket(book: Book) {
    let basket = sessionStorage.getItem("basket")
      ? JSON.parse(sessionStorage.getItem("basket"))
      : [];
    let bookFound = basket.find((b) => b.book._id === book._id);
    if (!bookFound) {
      basket.push({ book: book, amount: 1 });
    } else {
      bookFound.amount++;
    }

    sessionStorage.setItem("basket", JSON.stringify(basket));
  }

  getBasket() {
    return JSON.parse(sessionStorage.getItem("basket"));
  }

  updateBasket(basket) {
    sessionStorage.setItem("basket", JSON.stringify(basket));
  }
}
