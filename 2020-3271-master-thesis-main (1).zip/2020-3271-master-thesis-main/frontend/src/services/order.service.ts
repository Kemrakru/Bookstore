import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Order } from "src/app/model/order.model";
import { UserService } from "./user.service";

@Injectable({
  providedIn: "root",
})
export class OrderService {
  constructor(private http: HttpClient, private userService: UserService) {}

  backendUrl: string = "http://localhost:7000/order";

  create(order: Order) {
    delete order._id;
    let body = { data: order };
    return this.http.post(this.backendUrl, body);
  }

  send(order: Order) {
    order.sentDate = new Date().toJSON();
    let body = { data: order };
    return this.http.post(this.backendUrl + "/send", body);
  }

  getById(id: string) {
    return this.http.get(this.backendUrl + "/" + id);
  }

  getUserOrders() {
    let loggedInUserId = this.userService.getLoggedInUserId();
    return this.http.get(this.backendUrl + "/user/?userId=" + loggedInUserId);
  }

  getAll() {
    return this.http.get(this.backendUrl + "/");
  }

  convertToUSDApi() {
    let requestOptions = {
      headers: { apiKey: "BmCnRlwCyOiL6Jp1Aj53lzcYu8vooyE7" },
    };
    return this.http.get(
      "https://api.apilayer.com/fixer/latest?base=USD&symbols=RSD",
      requestOptions
    );
  }
}
