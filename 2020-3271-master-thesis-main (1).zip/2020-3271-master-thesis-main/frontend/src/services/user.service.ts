import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { User } from "src/app/model/user.model";

@Injectable({
  providedIn: "root",
})
export class UserService {
  constructor(private http: HttpClient) {}

  backendUrl: string = "http://localhost:7000/user";

  register(newUser: User) {
    delete newUser._id;
    let body = { data: newUser };
    return this.http.post(this.backendUrl, body);
  }

  login(email: string, password: string) {
    let body = { data: { email: email, password: password } };
    return this.http.post(this.backendUrl + "/login", body);
  }

  update(id: string, user: User, loggedinUserId: string) {
    console.log(id);
    let body = {
      data: JSON.parse(JSON.stringify(user)),
      userId: loggedinUserId,
    };
    delete body.data._id;
    return this.http.patch(this.backendUrl + "/" + id, body);
  }

  getLoggedInUser() {
    if (localStorage.getItem("bookstore-user")) {
      return JSON.parse(localStorage.getItem("bookstore-user"));
    }
    return null;
  }

  getLoggedInUserId() {
    if (localStorage.getItem("bookstore-user")) {
      let user = JSON.parse(localStorage.getItem("bookstore-user"));
      return user._id;
    }
    return null;
  }
}
