import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Coupon } from "src/app/model/coupon.model";
import { UserService } from "./user.service";

@Injectable({
  providedIn: "root",
})
export class CouponService {
  constructor(private http: HttpClient, private userService: UserService) {}

  backendUrl: string = "http://localhost:7000/coupon";

  create(coupon: Coupon, banner: string | ArrayBuffer) {
    let userId = this.userService.getLoggedInUserId();
    delete coupon._id;
    let body = { data: coupon, userId: userId, banner: banner };
    return this.http.post(this.backendUrl, body);
  }
  getActive() {
    return this.http.get(this.backendUrl + "/active");
  }
  getAll() {
    return this.http.get(this.backendUrl);
  }
  update(coupon: Coupon, banner: string | ArrayBuffer) {
    let userId = this.userService.getLoggedInUserId();
    const couponId = coupon._id;
    let body = {
      data: JSON.parse(JSON.stringify(coupon)),
      userId: userId,
      banner: banner,
    };
    delete body.data._id;
    return this.http.patch(this.backendUrl + "/" + couponId, body);
  }
  apply(couponText: string) {
    let body = { data: couponText };
    return this.http.post(this.backendUrl + "/apply", body);
  }
  delete(couponId: string) {
    let loggedInUserId = this.userService.getLoggedInUserId();
    return this.http.delete(
      this.backendUrl + "/?couponId=" + couponId + "&userId=" + loggedInUserId
    );
  }
}
