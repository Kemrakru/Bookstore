import { Component, Input, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { BasketService } from "src/services/basket.service";
import { BookService } from "src/services/book.service";
import { Book, books } from "../model/book.model";

@Component({
  selector: "app-books",
  templateUrl: "./books.component.html",
  styleUrls: ["./books.component.css"],
})
export class BooksComponent implements OnInit {
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private bookService: BookService,
    private basketService: BasketService
  ) {}

  @Input() title: string = "";
  books: Book[] = [];
  params: any = {};
  filteredBooks: Book[] = [];

  langs: string[] = [];
  bookPages: number[] = [];
  all_books: Book[] = [];
  pageSize = 8;
  selectedPage = { books: 1 };

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      this.params = {
        author: params["author"] ? params["author"] : "",
        category: params["category"] ? params["category"] : "",
        search: params["search"] ? params["search"] : "",
      };
      this.filterBooks(this.params);
    });
  }

  goToBook(bookId: string) {
    this.router.navigateByUrl("/book/" + bookId);
  }

  goToPage(pageNum: number) {
    this.selectedPage.books = pageNum;
    this.books = this.filteredBooks.slice(
      (pageNum - 1) * this.pageSize,
      pageNum * this.pageSize
    );
  }

  getPagesText1(entity: string) {
    return (this.selectedPage[entity] - 1) * this.pageSize + 1;
  }

  getPagesText2(entity: string) {
    return (this.selectedPage[entity] - 1) * this.pageSize + this.pageSize >
      this["all_" + entity].length
      ? this["all_" + entity].length
      : (this.selectedPage[entity] - 1) * this.pageSize + this.pageSize;
  }

  chosenSort: string = "popular";

  changeSortBooks(sortBy: string, sortBooks: string) {
    this.chosenSort = sortBy;
    switch (sortBy) {
      case "popular":
        this[sortBooks].sort((a, b) => (a.sold < b.sold ? 1 : -1));
        break;
      case "price-low-high":
        this[sortBooks].sort((a, b) => (a.price > b.price ? 1 : -1));
        break;
      case "price-high-low":
        this[sortBooks].sort((a, b) => (a.price < b.price ? 1 : -1));
        break;
      case "date-old-new":
        this[sortBooks].sort((a, b) =>
          new Date(a.pubDate) > new Date(b.pubDate) ? 1 : -1
        );
        break;
      case "date-new-old":
        this[sortBooks].sort((a, b) =>
          new Date(a.pubDate) < new Date(b.pubDate) ? 1 : -1
        );
        break;
    }
    this.goToPage(1);
  }

  goToAuthor(author: string) {
    this.router.navigate(["/books"], { queryParams: { author: author } });
  }

  filterFromChild(paramsFromSideBar: any) {
    this.filteredBooks = this.all_books.filter((b: Book) => {
      let langCheck =
        paramsFromSideBar.language !== "0"
          ? b.language === paramsFromSideBar.language
          : true;
      let typeCheck =
        paramsFromSideBar.type !== "0"
          ? b.coverType === paramsFromSideBar.type
          : true;
      let searchCheck = paramsFromSideBar.search
        ? b.title
            .toLowerCase()
            .includes(paramsFromSideBar.search.toLowerCase()) ||
          b.authors.find((a) =>
            a.toLowerCase().includes(paramsFromSideBar.search.toLowerCase())
          )
        : true;

      let priceCheck = true;
      if (paramsFromSideBar.priceRange !== "0") {
        switch (paramsFromSideBar.priceRange) {
          case "under":
            priceCheck = b.price < 15;
            break;
          case "between":
            priceCheck = b.price >= 15 && b.price <= 30;
            break;
          case "above":
            priceCheck = b.price > 30;
            break;
        }
      }

      return langCheck && searchCheck && priceCheck && typeCheck;
    });
    this.changeSortBooks(this.chosenSort, "filteredBooks");
  }

  filterBooks(params: any) {
    this.bookService.getFiltered(params).subscribe((dbBooks: Book[]) => {
      this.all_books = dbBooks;
      this.bookPages = Array.from(
        Array(Math.ceil(this.all_books.length / 8)).keys()
      );
      this.filteredBooks = JSON.parse(JSON.stringify(this.all_books));
      this.changeSortBooks("popular", "filteredBooks");
      this.all_books.forEach((b) => {
        if (b.language) {
          if (this.langs.indexOf(b.language) === -1) {
            this.langs.push(b.language);
          }
        }
      });
    });
  }
}
