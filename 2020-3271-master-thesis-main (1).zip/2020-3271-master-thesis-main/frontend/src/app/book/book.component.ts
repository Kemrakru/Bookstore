import { Component, OnInit } from "@angular/core";
import { DomSanitizer } from "@angular/platform-browser";
import { ActivatedRoute, Router } from "@angular/router";
import { BasketService } from "src/services/basket.service";
import { BookService } from "src/services/book.service";
import { WishlistService } from "src/services/wishlist.service";
import { Book } from "../model/book.model";
import { Wishlist, wishlistsArray } from "../model/wishlist.model";

@Component({
  selector: "app-book",
  templateUrl: "./book.component.html",
  styleUrls: ["./book.component.css"],
})
export class BookComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private basketService: BasketService,
    private sanitizer: DomSanitizer,
    private bookService: BookService,
    private wishlistService: WishlistService
  ) {}

  showMore: boolean = false;

  book: Book = null;

  wishlists: Wishlist[];
  addToWishlistDialog: boolean = false;
  wishlist: string = wishlistsArray[0]._id;

  editable = false;
  editBookInfo = false;
  editBookPrice = false;
  editBookDetails = false;
  editBookCategories = false;
  editedBook: Book;
  bookLoading: boolean = false;
  allCategories = [];

  ngOnInit() {
    this.bookLoading = true;
    let bookId = this.route.snapshot.paramMap.get("id");
    this.allCategories = this.bookService.allCategories;
    this.bookService.getById(bookId).subscribe((book: Book) => {
      this.book = book;
      this.bookLoading = false;
      this.route.queryParams.subscribe((params) => {
        if (params["edit"] && this.isAdmin()) {
          this.editable = params["edit"];
          this.editedBook = JSON.parse(JSON.stringify(this.book));
        }
      });
      this.wishlistService
        .getUserWishlists()
        .subscribe((wishlists: Wishlist[]) => {
          this.wishlists = wishlists;
          this.wishlist =
            this.wishlists && this.wishlists.length
              ? this.wishlists[0]._id
              : "";
        });
    });
  }

  addAuthor() {
    this.editedBook.authors.push("");
  }

  removeAuthor(name: string) {
    let index = this.editedBook.authors.indexOf(name);
    if (index !== -1) {
      this.editedBook.authors.splice(index, 1);
    }
  }

  removeCategory(cat: string) {
    let index = this.editedBook.categories.indexOf(cat);
    if (index !== -1) {
      this.editedBook.categories.splice(index, 1);
    }
  }

  addCat(cat: string) {
    let index = this.editedBook.categories.indexOf(cat);
    if (index === -1) {
      this.editedBook.categories.push(cat);
    }
  }

  coverImage: string | ArrayBuffer = null;
  coverImageName: string = "";
  onFileChange(event) {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length) {
      const file = event.target.files[0];
      this.coverImageName = file.name;
      reader.readAsDataURL(file);
      reader.onload = (e) => {
        this.coverImage = reader.result;
      };
    }
  }

  saveBookInfo() {
    if (typeof this.editedBook.available === "string") {
      this.editedBook.available = this.editedBook.available === "true";
    }

    if (this.coverImageName) {
      this.editedBook.cover = this.coverImageName;
    }
    this.bookService
      .update(this.editedBook._id, this.editedBook, this.coverImage)
      .subscribe((res: any) => {
        console.log(res);
        this.editBookInfo = false;
        this.editBookPrice = false;
        this.editBookDetails = false;
        this.editBookCategories = false;
        this.book = JSON.parse(JSON.stringify(this.editedBook));
      });
  }

  formatDate(dateString: string) {
    return new Date(dateString).toLocaleDateString("en-US");
  }

  goToAuthor(author: string) {
    this.router.navigate(["/books"], { queryParams: { author: author } });
  }

  isAdmin() {
    return (
      localStorage.getItem("bookstore-user") &&
      JSON.parse(localStorage.getItem("bookstore-user")).type === "admin"
    );
  }

  trackByFn(index, item) {
    return index;
  }

  loggedIn() {
    return localStorage.getItem("bookstore-user");
  }

  addToWishlist() {
    this.wishlistService
      .addToWishlist(this.wishlist, this.book)
      .subscribe((res: any) => {
        console.log(res);
        this.addToWishlistDialog = false;
      });
  }
}
