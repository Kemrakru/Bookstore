import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { Book } from "src/app/model/book.model";

@Component({
  selector: "app-filter",
  templateUrl: "./filter.component.html",
  styleUrls: ["./filter.component.css"],
})
export class FilterComponent implements OnInit {
  constructor(private router: Router, private route: ActivatedRoute) {}

  @Input() langs: string[] = [];
  @Input() books: Book[] = [];
  @Output() filterEvent = new EventEmitter<any>();

  keyword: string = "";
  type: string = "0";
  priceRange: string = "0";
  language: string = "0";

  ngOnInit() {}

  ngAfterViewChecked() {
    // if (this.books && this.books.length) {
    //   console.log(this.books)
    //   this.books.forEach(b =>
    //     {
    //       if (b.language)
    //       {
    //         if (this.langs.indexOf(b.language) === -1)
    //         {
    //           this.langs.push(b.language);
    //         }
    //       }
    //     })
    // }
  }

  filter() {
    const queryParams = {
      search: this.keyword,
      type: this.type,
      priceRange: this.priceRange,
      language: this.language,
    };
    this.filterEvent.emit(queryParams);
  }
}
