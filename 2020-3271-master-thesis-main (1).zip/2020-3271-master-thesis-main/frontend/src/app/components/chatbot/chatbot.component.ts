import { Component, OnInit } from "@angular/core";
import { ChatbotService } from "src/services/chatbot.service";

@Component({
  selector: "app-chatbot",
  templateUrl: "./chatbot.component.html",
  styleUrls: ["./chatbot.component.css"],
})
export class ChatbotComponent implements OnInit {
  constructor(private chatbotService: ChatbotService) {}

  userMsg = { text: "", user: true };
  messages;
  loadRobotMsg: boolean = false;

  ngOnInit() {
    if (sessionStorage.getItem("bookstore-chatbot-messages")) {
      this.messages = JSON.parse(
        sessionStorage.getItem("bookstore-chatbot-messages")
      );
    } else {
      this.messages = [{ text: "Hello! How you doing?", user: false }];
    }
  }

  addMsgToStorage(msg) {
    sessionStorage.setItem(
      "bookstore-chatbot-messages",
      JSON.stringify(this.messages)
    );
  }

  sendMsg() {
    if (this.userMsg.text) {
      this.messages.push({ text: this.userMsg.text, user: true });
      let usermessagetext = this.userMsg.text;
      this.addMsgToStorage({ text: usermessagetext, user: true });
      this.userMsg.text = "";
      this.loadRobotMsg = true;
      setTimeout(() => {
        this.chatbotService
          .getChatbotAnswer(usermessagetext)
          .subscribe((res: any) => {
            let robotAnswer: RobotAnswer = { text: "", user: false };
            if ("data" in res && res.data) {
              console.log(res.data);
              if (res.data.intent === "book") {
                let messageArray = res.data.message;
                messageArray.forEach((element) => {
                  let answer: RobotAnswer = { text: element, user: false };
                  console.log(answer);
                  this.messages.push(answer);
                });
              } else {
                robotAnswer = { text: res.data.message, user: false };
                this.messages.push(robotAnswer);
              }
            }
            this.addMsgToStorage(robotAnswer);
            this.loadRobotMsg = false;
          });
      }, 500);
    }
  }

  chatbotClicked() {
    if (document.getElementById("chatbot").classList.contains("hideChatbot")) {
      document.getElementById("chatbot").classList.remove("hideChatbot");
      var chatHistory = document.getElementById("lastMsg");
      chatHistory.scrollTop = chatHistory.scrollHeight;
    } else {
      document.getElementById("chatbot").classList.add("hideChatbot");
    }
  }
}

export type RobotAnswer = { text: string; user: boolean };
