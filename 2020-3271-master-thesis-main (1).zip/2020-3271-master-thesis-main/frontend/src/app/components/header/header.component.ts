import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { BasketService } from "src/services/basket.service";
import { BookService } from "src/services/book.service";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"],
})
export class HeaderComponent implements OnInit {
  constructor(
    private router: Router,
    private basketService: BasketService,
    private bookService: BookService
  ) {}

  searchTerm: string = "";
  categories: string[] = [];

  ngOnInit() {
    this.categories = this.bookService.allCategories;
  }

  goToBasket() {
    this.router.navigate(["basket"]);
  }

  search() {
    this.router.navigate(["/books"], {
      queryParams: { search: this.searchTerm },
    });
  }

  isUserLoggedIn() {
    return localStorage.getItem("bookstore-user");
  }

  isAdmin() {
    return (
      localStorage.getItem("bookstore-user") &&
      JSON.parse(localStorage.getItem("bookstore-user")).type === "admin"
    );
  }

  logout() {
    localStorage.removeItem("bookstore-user");
    this.router.navigate(["/home"]);
  }
}
