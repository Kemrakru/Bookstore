import { Component, OnInit, ViewChild } from "@angular/core";
import { Router } from "@angular/router";
import { BasketService } from "src/services/basket.service";
import { OrderService } from "src/services/order.service";
import { UserService } from "src/services/user.service";
import { Coupon } from "../model/coupon.model";
import { BookItem, Order } from "../model/order.model";
import { User } from "../model/user.model";
import { createWallet, KinClient, KinTest, Wallet } from "@kin-sdk/client";
import { IPayPalConfig, ICreateOrderRequest } from "ngx-paypal";

import { HttpClient } from "@angular/common/http";
import { Observable, switchMap } from "rxjs";
const client = new KinClient(KinTest, { appIndex: 438 });

import { StripeService, StripePaymentElementComponent } from "ngx-stripe";
import { StripeElementsOptions, PaymentIntent } from "@stripe/stripe-js";
import { FormBuilder, Validators } from "@angular/forms";

@Component({
  selector: "app-checkout",
  templateUrl: "./checkout.component.html",
  styleUrls: ["./checkout.component.css"],
})
export class CheckoutComponent implements OnInit {
  public payPalConfig?: IPayPalConfig;
  constructor(
    private router: Router,
    private http: HttpClient,
    private userService: UserService,
    private orderService: OrderService,
    private basketService: BasketService,
    private stripeService: StripeService,
    private fb: FormBuilder
  ) {}

  user: User = null;
  userInfo = {
    email: "",
    fullname: "",
    address: "",
    town: "",
    state: "",
    zip: "",
    phone: "",
    country: "",
  };
  order: Order = {
    _id: "",
    books: [],
    couponCode: "",
    couponId: "",
    paymentType: "",
    price: 0,
    sentDate: "",
    timestamp: "",
    userId: this.user ? this.user._id : null,
    userInfo: this.userInfo,
  };
  coupon: Coupon = null;
  basket: any = [];
  orderCompleted: boolean = false;

  ngOnInit() {
    this.initConfig();
    this.user = this.userService.getLoggedInUser();
    if (!this.basketService.getBasket()) {
      this.router.navigate(["/home"]);
    }
    if (this.user) {
      for (const value in this.userInfo) {
        if (["name", "password", "type", "_id"].includes(value)) {
          continue;
        }
        this.userInfo[value] = this.user[value];
      }
    }
    this.coupon = sessionStorage.getItem("bookstore-coupon")
      ? JSON.parse(sessionStorage.getItem("bookstore-coupon"))
      : null;
    let basket = this.basketService.getBasket();
    let books = [];
    basket.forEach((b) => {
      books.push({ bookId: b.book._id, amount: b.amount });
    });
    this.basket = basket;
    this.orderService.convertToUSDApi().subscribe((res: any) => {
      let amount = this.getTotalCostWithCoupon();
      let rates = 118;
      if (res.success) {
        rates = res.rates.RSD;
      }
      this.order = {
        _id: "",
        books: books,
        couponCode: this.coupon ? this.coupon.code : "",
        couponId: this.coupon ? this.coupon._id : "",
        paymentType: "",
        price: Number((amount / rates).toFixed(2)),
        sentDate: "",
        timestamp: "",
        userId: this.user ? this.user._id : null,
        userInfo: this.userInfo,
      };
      this.createPaymentIntent(this.order.price).subscribe((pi) => {
        this.elementsOptions.clientSecret = pi.client_secret;
      });
    });
  }

  getTotalCost(basket: any) {
    return basket.reduce(
      (partialSum, a) => partialSum + a.book.price * a.amount,
      0
    );
  }

  getTotalCostWithCoupon() {
    return (
      this.getTotalCost(this.basket) -
      (this.coupon
        ? this.getTotalCost(this.basket) * (this.coupon.discount / 100)
        : 0)
    );
  }

  paymentType = "stripe";

  createOrder() {
    this.order.timestamp = new Date().toJSON();
    this.order.paymentType = this.paymentType;
    this.orderService.create(this.order).subscribe((newOrder: any) => {
      console.log(newOrder);
      sessionStorage.removeItem("basket");
      sessionStorage.removeItem("bookstore-coupon");
      this.orderCompleted = true;
    });
  }

  @ViewChild(StripePaymentElementComponent)
  paymentElement: StripePaymentElementComponent;

  paymentElementForm = this.fb.group({
    name: ["John doe", [Validators.required]],
    email: ["support@ngx-stripe.dev", [Validators.required]],
    address: [""],
    zipcode: [""],
    city: [""],
    amount: [2500, [Validators.required, Validators.pattern(/d+/)]],
  });

  elementsOptions: StripeElementsOptions = {
    locale: "en",
  };

  paying = false;

  private createPaymentIntent(amount: number): Observable<PaymentIntent> {
    return this.http.post<PaymentIntent>(
      "http://localhost:7000/create-payment-intent",
      { amount }
    );
  }

  pay() {
    this.paying = true;
    this.stripeService
      .confirmPayment({
        elements: this.paymentElement.elements,
        confirmParams: {
          payment_method_data: {
            billing_details: {
              name: this.order.userInfo.fullname,
              email: this.order.userInfo.email,
              address: {
                line1: this.order.userInfo.address,
                postal_code: this.order.userInfo.zip,
                city: this.order.userInfo.town,
              },
            },
          },
        },
        redirect: "if_required",
      })
      .subscribe((result) => {
        this.paying = false;
        console.log("Result", result);
        if (result.error) {
          // Show error to your customer (e.g., insufficient funds)
          alert(result.error.message);
        } else {
          // The payment has been processed!
          if (result.paymentIntent.status === "succeeded") {
            // Show a success message to your customer
            this.createOrder();
          }
        }
      });
  }

  checkout() {
    this.pay();
  }

  created = false;
  wallet?: Wallet;
  result1?: string;
  result2?: string;
  result3?: string;
  result4?: string;
  result5?: string;

  async setKinPayment() {
    this.paymentType = "kin";
    this.generateKeyPair();
    await this.createAccount();
    await this.getBalances();
    await this.getMyBalance();
  }

  generateKeyPair(): void {
    this.wallet = createWallet("create");
  }

  async createAccount(): Promise<void> {
    this.result1 = "createAccount";
    const [res, err] = await client.createAccount(
      this.wallet ? this.wallet.secret : ""
    );
    if (err) {
      this.result1 = JSON.stringify(err);
    } else {
      this.result1 = JSON.stringify(res);
      this.created = true;
    }
  }

  async getBalances(): Promise<void> {
    this.result2 = "getBalances";
    const [res, err] = await client.getBalances(
      this.wallet ? this.wallet.publicKey : ""
    );
    if (err) {
      this.result2 = JSON.stringify(err);
    } else {
      this.result2 = JSON.stringify(res);
    }
  }

  async getMyBalance(): Promise<void> {
    const [res, err] = await client.getBalances(
      "K1s8xwD8QT6oVdA1WK5DsDrrscFJYJFATaRH41mpYcV"
    );
    if (err) {
      this.result5 = JSON.stringify(err);
    } else {
      this.result5 = JSON.stringify(res);
    }
  }

  async requestAirdrop(): Promise<void> {
    this.result3 = "requestAirdrop";
    const airdropAmount = this.order.price.toString();
    const [res, err] = await client.requestAirdrop(
      this.wallet ? this.wallet.publicKey : "",
      airdropAmount
    );
    if (err) {
      this.result3 = JSON.stringify(err);
    } else {
      this.result3 = JSON.stringify(res);
      await this.getBalances();
    }
  }

  async submitPayment(): Promise<void> {
    this.result4 = "submitPayment";
    const airdropAmount = (this.order.price * 1).toString();
    const [res, err] = await client.submitPayment({
      secret: this.wallet ? this.wallet.secret : "",
      tokenAccount: this.wallet ? this.wallet.publicKey : "",
      amount: airdropAmount,
      destination: "K1s8xwD8QT6oVdA1WK5DsDrrscFJYJFATaRH41mpYcV",
    });
    if (err) {
      this.result4 = JSON.stringify(err);
    } else {
      this.result4 = JSON.stringify(res);
      await this.getBalances();
      await this.getMyBalance();
    }
  }

  private initConfig(): void {
    this.payPalConfig = {
      currency: "USD",
      clientId:
        "AVkn9UF1sNvgeFhKPNAoz1QzFAGYeQcNyl0uAAWDfM-z_67FX16X8L8tj4kzQoj2yXdmSMeRy9CU1S-r",
      createOrderOnClient: (data) =>
        <ICreateOrderRequest>{
          intent: "CAPTURE",
          purchase_units: [
            {
              amount: {
                currency_code: "USD",
                value: this.order.price.toString(),
                breakdown: {
                  item_total: {
                    currency_code: "USD",
                    value: this.order.price.toString(),
                  },
                },
              },
              items: [
                {
                  name: "Books",
                  quantity: "1",
                  category: "PHYSICAL_GOODS",
                  unit_amount: {
                    currency_code: "USD",
                    value: this.order.price.toString(),
                  },
                },
              ],
            },
          ],
        },
      advanced: {
        commit: "true",
      },
      style: {
        label: "paypal",
        layout: "horizontal",
      },
      onApprove: (data, actions) => {
        console.log(
          "onApprove - transaction was approved, but not authorized",
          data,
          actions
        );
        actions.order.get().then((details) => {
          console.log(
            "onApprove - you can get full order details inside onApprove: ",
            details
          );
        });
      },
      onClientAuthorization: (data) => {
        console.log(
          "onClientAuthorization - you should probably inform your server about completed transaction at this point",
          data
        );
        this.createOrder();
      },
      onCancel: (data, actions) => {
        console.log("OnCancel", data, actions);
      },
      onError: (err) => {
        console.log("OnError", err);
      },
      onClick: (data, actions) => {
        console.log("onClick", data, actions);
      },
    };
  }

  setPaymentType(type: string) {
    this.paymentType = type;
  }
}
