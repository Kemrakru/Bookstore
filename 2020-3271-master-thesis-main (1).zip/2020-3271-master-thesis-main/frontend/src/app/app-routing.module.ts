import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { BasketComponent } from "./basket/basket.component";

import { BookComponent } from "./book/book.component";
import { BooksComponent } from "./books/books.component";
import { CheckoutComponent } from "./checkout/checkout.component";
import { HomeComponent } from "./home/home.component";
import { ManageComponent } from "./manage/manage.component";
import { OrderComponent } from "./order/order.component";
import { LoginComponent } from "./user/login/login.component";
import { OrdersComponent } from "./user/orders/orders.component";
import { ProfileComponent } from "./user/profile/profile.component";
import { WishlistComponent } from "./user/wishlist/wishlist.component";

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "home", component: HomeComponent },
  { path: "basket", component: BasketComponent },
  { path: "book/:id", component: BookComponent },
  { path: "books", component: BooksComponent },
  { path: "login", component: LoginComponent },
  { path: "profile", component: ProfileComponent },
  { path: "wishlist", component: WishlistComponent },
  { path: "orders", component: OrdersComponent },
  { path: "order/:id", component: OrderComponent },
  { path: "checkout", component: CheckoutComponent },
  { path: "manage", component: ManageComponent },
  { path: "**", component: HomeComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
