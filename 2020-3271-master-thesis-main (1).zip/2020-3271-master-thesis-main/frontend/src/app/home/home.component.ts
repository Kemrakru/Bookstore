import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { BasketService } from "src/services/basket.service";
import { BookService } from "src/services/book.service";
import { CouponService } from "src/services/coupon.service";
import { Book, books } from "../model/book.model";
import { Coupon, coupons } from "../model/coupon.model";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"],
})
export class HomeComponent implements OnInit {
  constructor(
    private router: Router,
    private basketService: BasketService,
    private couponService: CouponService,
    private bookService: BookService
  ) {}

  books: Book[] = [];
  coupons: Coupon[] = [];

  ngOnInit() {
    // get active coupons from backend
    this.couponService.getActive().subscribe((coupons: Coupon[]) => {
      this.coupons = coupons;
      this.bookService.getBestSellingBooks().subscribe((books: Book[]) => {
        this.books = books;
      });
    });
  }

  goToBook(bookId: string) {
    this.router.navigateByUrl("/book/" + bookId);
  }

  goToAuthor(author) {
    this.router.navigate(["/books"], { queryParams: { author: author } });
  }
}
