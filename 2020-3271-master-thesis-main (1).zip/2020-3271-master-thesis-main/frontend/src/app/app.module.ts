import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { FormBuilder, FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { HeaderComponent } from "./components/header/header.component";
import { FooterComponent } from "./components/footer/footer.component";
import { HomeComponent } from "./home/home.component";
import { BookComponent } from "./book/book.component";
import { FilterComponent } from "./components/filter/filter.component";
import { BasketComponent } from "./basket/basket.component";
import { CheckoutComponent } from "./checkout/checkout.component";
import { BooksComponent } from "./books/books.component";
import { ProfileComponent } from "./user/profile/profile.component";
import { WishlistComponent } from "./user/wishlist/wishlist.component";
import { OrdersComponent } from "./user/orders/orders.component";
import { LoginComponent } from "./user/login/login.component";
import { ManageComponent } from "./manage/manage.component";
import { ChatbotComponent } from "./components/chatbot/chatbot.component";
import { OrderComponent } from "./order/order.component";
import { NgxPayPalModule } from "ngx-paypal";
import { NgxStripeModule, StripeService } from "ngx-stripe";

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    BookComponent,
    FilterComponent,
    BasketComponent,
    CheckoutComponent,
    BooksComponent,
    ProfileComponent,
    WishlistComponent,
    OrdersComponent,
    LoginComponent,
    ManageComponent,
    ChatbotComponent,
    OrderComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPayPalModule,
    NgxStripeModule.forRoot(
      "pk_test_51JcC8UJVtxBqJxu3V1VlZb1eXxN1N2GxorsHDcpOGJcfpdWWNcfYBqTk5mrUX2rBBWGz0ETr7gpBDOFAErggpDBs00Pvlou8Zj"
    ),
  ],
  providers: [StripeService, FormBuilder],
  bootstrap: [AppComponent],
})
export class AppModule {}
