import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { BookService } from "src/services/book.service";
import { CouponService } from "src/services/coupon.service";
import { OrderService } from "src/services/order.service";
import { Book, books } from "../model/book.model";
import { Coupon, coupons } from "../model/coupon.model";
import { Order } from "../model/order.model";
import { User, users } from "../model/user.model";

@Component({
  selector: "app-manage",
  templateUrl: "./manage.component.html",
  styleUrls: ["./manage.component.css"],
})
export class ManageComponent implements OnInit {
  constructor(
    private router: Router,
    private bookService: BookService,
    private orderService: OrderService,
    private couponService: CouponService
  ) {}

  menuItems = ["Books", "Orders", "Coupons"];
  activeMenuItem: string = "Books";
  books: Book[] = [];
  allCategories: string[] = [];
  user: User;
  bookPagesCount: number = 0;
  allBooksCount: number = 0;
  bookPages: number[] = [];
  couponPages: number[] = [];
  all_books: Book[] = [];
  pageSize = 8;
  selectedPage = { books: 1, coupons: 1, orders: 1 };

  ngOnInit() {
    if (
      !localStorage.getItem("bookstore-user") ||
      JSON.parse(localStorage.getItem("bookstore-user")).type !== "admin"
    ) {
      this.router.navigate(["/home"]);
    } else {
      this.user = JSON.parse(localStorage.getItem("bookstore-user"));
      this.allCategories = this.bookService.allCategories;
      this.getBooks();
      this.getOrders();
      this.getCoupons();
    }
  }

  getBooks() {
    this.bookService.getFiltered(null).subscribe((dbBooks: Book[]) => {
      this.all_books = dbBooks;
      this.allBooksCount = dbBooks.length;
      this.bookPagesCount = Math.ceil(this.allBooksCount / 8);
      this.bookPages = Array.from(Array(this.bookPagesCount).keys());
      this.changeSortBooks("popular");
    });
  }
  getOrders() {
    this.orderService.getAll().subscribe((orders: Order[]) => {
      this.all_orders = orders;
      this.orderPages = Array.from(
        Array(Math.ceil(this.all_coupons.length / 8)).keys()
      );
      this.goToPage(1, "orders");
    });
  }
  getCoupons() {
    this.couponService.getAll().subscribe((coupons: Coupon[]) => {
      this.all_coupons = coupons;
      this.couponPages = Array.from(
        Array(Math.ceil(this.all_coupons.length / 8)).keys()
      );
      this.goToPage(1, "coupons");
    });
  }

  goToPage(pageNum: number, entity: string) {
    this.selectedPage[entity] = pageNum;
    this[entity] = this["all_" + entity].slice(
      (pageNum - 1) * this.pageSize,
      pageNum * this.pageSize
    );
  }

  getPagesText1(entity: string) {
    return (this.selectedPage[entity] - 1) * this.pageSize + 1;
  }

  getPagesText2(entity: string) {
    return (this.selectedPage[entity] - 1) * this.pageSize + this.pageSize >
      this["all_" + entity].length
      ? this["all_" + entity].length
      : (this.selectedPage[entity] - 1) * this.pageSize + this.pageSize;
  }

  changeSortBooks(sortBy: string) {
    switch (sortBy) {
      case "popular":
        this.all_books.sort((a, b) => (a.sold < b.sold ? 1 : -1));
        break;
      case "price-low-high":
        this.all_books.sort((a, b) => (a.price > b.price ? 1 : -1));
        break;
      case "price-high-low":
        this.all_books.sort((a, b) => (a.price < b.price ? 1 : -1));
        break;
      case "date-old-new":
        this.all_books.sort((a, b) =>
          new Date(a.pubDate) > new Date(b.pubDate) ? 1 : -1
        );
        break;
      case "date-new-old":
        this.all_books.sort((a, b) =>
          new Date(a.pubDate) < new Date(b.pubDate) ? 1 : -1
        );
        break;
    }
    this.goToPage(1, "books");
  }

  goToAuthor(author) {
    this.router.navigate(["/books"], { queryParams: { author: author } });
  }

  changeItem(item: string) {
    this.activeMenuItem = item;
  }

  deleteBook(book: Book) {
    //make unavailable
    book.available = false;
    this.bookService.update(book._id, book, null).subscribe((book: Book) => {
      console.log(book);
      let index = this.books.indexOf(book);
      if (index !== -1) {
        this.books[index] = book;
      }
    });
  }

  goToBook(bookId: string) {
    this.router.navigateByUrl("/book/" + bookId);
  }

  editBook(book: Book) {
    this.router.navigateByUrl("/book/" + book._id + "?edit=true");
  }

  newBook: Book = {
    _id: "0",
    amount: 0,
    authors: [""],
    available: true,
    categories: [],
    cover: "",
    description: "",
    isbn: "",
    language: "English",
    pages: 0,
    price: 0,
    pubDate: "",
    publisher: "",
    rating: "",
    ratingsNum: "",
    sold: 0,
    title: "",
    coverType: "Paperback",
  };

  resetNewBook(): void {
    this.newBook = {
      _id: "0",
      amount: 0,
      authors: [""],
      available: true,
      categories: [],
      cover: "",
      description: "",
      isbn: "",
      language: "English",
      pages: 0,
      price: 0,
      pubDate: "",
      publisher: "",
      rating: "",
      ratingsNum: "",
      sold: 0,
      title: "",
      coverType: "Paperback",
    };
  }
  closeAddNewBook() {
    this.addNewBook = false;
    this.resetNewBook();
  }

  addNewBook: boolean = false;

  newEntity() {
    if (this.activeMenuItem === "Books") {
      this.addNewBook = true;
    } else if (this.activeMenuItem === "Coupons") {
      this.addNewCoupon = true;
      this.editCoupon = {
        _id: "0",
        amount: 0,
        categories: [],
        code: "",
        dateTo: "",
        name: "",
        banner: "",
        discount: 0,
      };
    }
  }

  trackByFn(index, item) {
    return index;
  }

  addAuthor() {
    this.newBook.authors.push("");
  }

  removeAuthor(name: string) {
    let index = this.newBook.authors.indexOf(name);
    if (index !== -1) {
      this.newBook.authors.splice(index, 1);
    }
  }

  coverImage: string | ArrayBuffer;
  coverImageName: string = "";
  onFileChange(event) {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length) {
      const file = event.target.files[0];
      this.coverImageName = file.name;
      reader.readAsDataURL(file);
      reader.onload = (e) => {
        this.coverImage = reader.result;
      };
    }
  }

  saveBookInfo() {
    if (typeof this.newBook.available === "string") {
      this.newBook.available = this.newBook.available === "true";
    }
    this.newBook.cover = this.coverImageName;
    if (this.newBook.isbn && this.newBook.title) {
      this.bookService
        .createBook(this.newBook, this.user._id, this.coverImage)
        .subscribe((res: any) => {
          console.log(res);
          this.addNewBook = false;
          this.resetNewBook();
          this.getBooks();
        });
    }
  }

  selectCategory(cat: string) {
    let index = this.newBook.categories.indexOf(cat);
    if (index !== -1) {
      this.newBook.categories.splice(index, 1);
    } else {
      this.newBook.categories.push(cat);
    }
  }

  orders: Order[] = [];
  all_orders: Order[] = [];
  orderPages: number[] = [];

  openOrder(order: Order) {
    this.router.navigate(["/order/" + order._id]);
  }

  sendOrder(order: Order) {
    if (!order.sentDate) {
      this.orderService.send(order).subscribe((res: any) => {
        window.location.reload();
      });
    }
  }
  getTimestamp(order: Order) {
    return new Date(order.timestamp).toLocaleString();
  }

  coupons: Coupon[] = [];
  all_coupons: Coupon[] = [];
  addNewCoupon: boolean = false;
  editCoupon: Coupon = {
    _id: "0",
    amount: 0,
    categories: [],
    code: "",
    dateTo: "",
    name: "",
    banner: "",
    discount: 0,
  };

  formatDate(dateString: string) {
    return new Date(dateString).toLocaleDateString("en-US");
  }

  editCouponEntity(coupon: Coupon) {
    this.addNewCoupon = true;
    this.editCoupon = coupon;
  }

  addCatToCoupon(cat: string) {
    let index = this.editCoupon.categories.indexOf(cat);
    if (index !== -1) {
      this.editCoupon.categories.splice(index, 1);
    } else {
      this.editCoupon.categories.push(cat);
    }
  }

  couponBanner: string | ArrayBuffer;
  couponBannerName: string = "";
  onFileBannerChange(event) {
    const reader = new FileReader();
    if (event.target.files && event.target.files.length) {
      const file = event.target.files[0];
      this.couponBannerName = file.name;
      reader.readAsDataURL(file);
      reader.onload = (e) => {
        this.couponBanner = reader.result;
      };
    }
  }
  saveCouponInfo() {
    console.log(this.couponBannerName);
    this.editCoupon.banner = this.couponBannerName
      ? this.couponBannerName
      : this.editCoupon.banner;
    console.log(this.editCoupon);
    if (this.editCoupon._id === "0") {
      this.couponService
        .create(this.editCoupon, this.couponBanner)
        .subscribe((coupon: Coupon) => {
          console.log(coupon);
          this.coupons.push(coupon);
          this.addNewCoupon = false;
        });
    } else {
      this.couponService
        .update(this.editCoupon, this.couponBanner)
        .subscribe((coupon: Coupon) => {
          console.log(coupon);
          let index = this.coupons.indexOf(this.editCoupon);
          if (index !== -1) {
            this.coupons[index] = this.editCoupon;
          }
          this.addNewCoupon = false;
          this.getCoupons();
        });
    }
  }

  deleteCoupon(coupon: Coupon) {
    this.couponService.delete(coupon._id).subscribe(() => {
      let index = this.coupons.indexOf(coupon);
      if (index !== -1) {
        this.coupons.splice(index, 1);
      }
      this.addNewCoupon = false;
    });
  }
}
