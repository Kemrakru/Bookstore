import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { BasketService } from "src/services/basket.service";
import { CouponService } from "src/services/coupon.service";
import { Book } from "../model/book.model";
import { Coupon } from "../model/coupon.model";

@Component({
  selector: "app-basket",
  templateUrl: "./basket.component.html",
  styleUrls: ["./basket.component.css"],
})
export class BasketComponent implements OnInit {
  constructor(
    private basketService: BasketService,
    private router: Router,
    private couponService: CouponService
  ) {}

  basket: any;
  coupon = null;
  couponText: string = "";
  active_coupons: Coupon[] = [];

  ngOnInit() {
    this.basket = this.basketService.getBasket();
    this.couponService.getActive().subscribe((coupons: Coupon[]) => {
      this.active_coupons = coupons;
    });
  }

  apply() {
    if (!this.couponText) {
      this.coupon = null;
      return;
    }
    this.coupon = this.active_coupons.find(
      (c: Coupon) => c.code === this.couponText
    );
  }

  removeFromBasket(book: Book) {
    let index = this.basket.indexOf(book);
    if (index !== -1) {
      this.basket.splice(index, 1);
      this.basketService.updateBasket(this.basket);
    }
  }

  getTotalCost() {
    return this.basket.reduce(
      (partialSum, a) => partialSum + a.book.price * a.amount,
      0
    );
  }

  checkout() {
    this.apply();
    if (this.coupon) {
      sessionStorage.setItem("bookstore-coupon", JSON.stringify(this.coupon));
    }

    this.router.navigate(["checkout"]);
  }
}
