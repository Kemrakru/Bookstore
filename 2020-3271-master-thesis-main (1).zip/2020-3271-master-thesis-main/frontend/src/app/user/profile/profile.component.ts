import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { User } from "src/app/model/user.model";
import { UserService } from "src/services/user.service";

@Component({
  selector: "app-profile",
  templateUrl: "./profile.component.html",
  styleUrls: ["./profile.component.css"],
})
export class ProfileComponent implements OnInit {
  constructor(private router: Router, private userService: UserService) {}

  profile: User;
  changePassClicked: boolean = false;
  newPass: string = "";

  ngOnInit() {
    if (!localStorage.getItem("bookstore-user")) {
      this.router.navigate(["/home"]);
    } else {
      this.profile = JSON.parse(localStorage.getItem("bookstore-user"));
      this.userService
        .login(this.profile.email, this.profile.password)
        .subscribe((res: any) => {
          if (res.data[0].user) {
            this.profile = res.data[0].user;
            localStorage.setItem(
              "bookstore-user",
              JSON.stringify(this.profile)
            );
          } else {
            this.router.navigate(["/home"]);
          }
        });
    }
  }

  changePass() {
    if (!this.changePassClicked) {
      this.changePassClicked = true;
      return;
    }
    if (this.newPass) {
      this.profile.password = this.newPass;
      this.userService
        .update(this.profile._id, this.profile, this.profile._id)
        .subscribe((res: any) => {
          this.changePassClicked = !this.changePassClicked;
        });
    }
  }

  updateProfileInfo() {
    this.userService
      .update(this.profile._id, this.profile, this.profile._id)
      .subscribe((res: any) => {
        window.location.reload();
      });
  }
}
