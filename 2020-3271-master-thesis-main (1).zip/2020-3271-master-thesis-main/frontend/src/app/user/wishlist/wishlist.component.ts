import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { take } from "rxjs";
import { Book, books } from "src/app/model/book.model";
import { User } from "src/app/model/user.model";
import { Wishlist, wishlistsArray } from "src/app/model/wishlist.model";
import { BasketService } from "src/services/basket.service";
import { WishlistService } from "src/services/wishlist.service";

@Component({
  selector: "app-wishlist",
  templateUrl: "./wishlist.component.html",
  styleUrls: ["./wishlist.component.css"],
})
export class WishlistComponent implements OnInit {
  constructor(
    private router: Router,
    private wishlistService: WishlistService,
    private basketService: BasketService
  ) {}

  selectedWishlist: Wishlist;
  wishlists: Wishlist[] = [];
  createNewWishlist = false;
  newWishlistName = "";
  bookPages: number[] = [];
  all_books: Book[] = [];
  pageSize = 4;
  selectedPage = { books: 1 };
  booksToShow: Book[] = [];
  user: User;

  ngOnInit() {
    if (localStorage.getItem("bookstore-user")) {
      this.user = JSON.parse(localStorage.getItem("bookstore-user"));
      this.getWishlists();
    } else {
      this.router.navigate(["/home"]);
    }
  }

  isSelected(wishlist: Wishlist) {
    if (this.selectWishlist) {
      return this.selectedWishlist._id === wishlist._id;
    } else {
      return false;
    }
  }
  getWishlists() {
    this.wishlistService
      .getUserWishlists(this.user._id)
      .pipe(take(1))
      .subscribe((wishlists: Wishlist[]) => {
        this.wishlists = wishlists;
        this.selectedWishlist = this.wishlists.find((w) => w.default);
        this.bookPages = Array.from(
          Array(
            Math.ceil(this.selectedWishlist.books.length / this.pageSize)
          ).keys()
        );
        this.goToPage(1, "books");
      });
  }

  goToPage(pageNum: number, entity: string) {
    this.selectedPage[entity] = pageNum;
    this.booksToShow = this.selectedWishlist.books.slice(
      (pageNum - 1) * this.pageSize,
      pageNum * this.pageSize
    );
  }

  getPagesText1(entity: string) {
    return (this.selectedPage[entity] - 1) * this.pageSize + 1;
  }

  getPagesText2(entity: string) {
    return (this.selectedPage[entity] - 1) * this.pageSize + this.pageSize >
      this.selectedWishlist.books.length
      ? this.selectedWishlist.books.length
      : (this.selectedPage[entity] - 1) * this.pageSize + this.pageSize;
  }

  selectWishlist(id: string) {
    this.selectedWishlist = this.wishlists.find((w) => w._id === id);
    this.goToPage(1, "books");
    this.bookPages = Array.from(
      Array(
        Math.ceil(this.selectedWishlist.books.length / this.pageSize)
      ).keys()
    );
  }

  goToBook(bookId: string) {
    this.router.navigateByUrl("/book/" + bookId);
  }

  deleteFromList(book: Book) {
    this.wishlistService
      .deleteFromWishlist(this.selectedWishlist._id, book._id)
      .subscribe(() => {
        this.getWishlists();
      });
  }

  create() {
    let newWishlist: Wishlist = {
      _id: "0",
      name: this.newWishlistName,
      books: [],
      default: false,
      userId: "",
    };
    this.wishlistService.create(newWishlist).subscribe((res: any) => {
      if (res.data[0]) {
        this.wishlists.push(newWishlist);
        this.createNewWishlist = false;
      }
    });
  }

  deleteWishlist(wishlist: Wishlist) {
    this.wishlistService.delete(wishlist._id).subscribe((res: any) => {
      let index = this.wishlists.indexOf(wishlist);
      if (index !== -1) {
        this.wishlists.splice(index, 1);
      }
      if (this.selectedWishlist._id == wishlist._id) {
        this.selectedWishlist = this.wishlists.find((w) => w.default);
      }
    });
  }
}
