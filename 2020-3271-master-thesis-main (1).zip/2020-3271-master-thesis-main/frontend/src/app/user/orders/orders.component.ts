import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { books } from "src/app/model/book.model";
import { Order } from "src/app/model/order.model";
import { User, users } from "src/app/model/user.model";
import { OrderService } from "src/services/order.service";

@Component({
  selector: "app-orders",
  templateUrl: "./orders.component.html",
  styleUrls: ["./orders.component.css"],
})
export class OrdersComponent implements OnInit {
  constructor(private router: Router, private orderService: OrderService) {}

  activeOrders: Order[];
  pastOrders: Order[];

  orders: Order[];
  menuItems = ["Active Orders", "Past Orders"];
  activeMenuItem = "Active Orders";

  user: User;

  orderPages: number[] = [];
  all_orders: Order[] = [];
  pageSize = 8;
  selectedPage = { orders: 1 };

  ngOnInit() {
    if (!localStorage.getItem("bookstore-user")) {
      this.router.navigate(["/home"]);
      return;
    }
    this.user = JSON.parse(localStorage.getItem("bookstore-user"));
    this.orderService.getUserOrders().subscribe((orders: Order[]) => {
      console.log(orders);
      this.all_orders = orders;
      this.orderPages = Array.from(Array(Math.ceil(orders.length / 8)).keys());
      this.goToPage(1);
      this.orders = this.activeOrders;
    });
  }
  goToPage(pageNum: number) {
    this.selectedPage.orders = pageNum;
    this.activeOrders = this.all_orders
      .filter((o) => !o.sentDate)
      .slice((pageNum - 1) * this.pageSize, pageNum * this.pageSize);
    this.pastOrders = this.all_orders
      .filter((o) => o.sentDate)
      .slice((pageNum - 1) * this.pageSize, pageNum * this.pageSize);
  }

  getPagesText1(entity: string) {
    return (this.selectedPage[entity] - 1) * this.pageSize + 1;
  }

  getPagesText2(entity: string) {
    return (this.selectedPage[entity] - 1) * this.pageSize + this.pageSize >
      this["all_" + entity].length
      ? this["all_" + entity].length
      : (this.selectedPage[entity] - 1) * this.pageSize + this.pageSize;
  }

  openOrder(order: Order) {
    this.router.navigate(["/order/" + order._id]);
  }

  changeItem(menuItem: string) {
    this.activeMenuItem = menuItem;
    this.orders =
      this.activeMenuItem === "Active Orders"
        ? this.activeOrders
        : this.pastOrders;
  }

  getTimestamp(order: Order) {
    return new Date(order.timestamp).toLocaleString();
  }

  goToBook(bookId: string) {
    this.router.navigateByUrl("/book/" + bookId);
  }

  formatDate(dateString: string) {
    return new Date(dateString).toLocaleDateString("en-US");
  }

  getCover(id: string) {
    let book = books.find((b) => b._id == id);
    if (book) {
      return book.cover;
    }
    return "noimage.png";
  }

  getTitle(id: string) {
    let book = books.find((b) => b._id === id);
    if (book) {
      return book.title;
    }
    return "No Title";
  }

  getPersonName(order: Order) {
    if (order.userId) {
      let user = users.find((u) => u._id === order.userId);
      return user ? user.fullname : "";
    } else {
      return order.userInfo ? order.userInfo.fullname : "";
    }
  }
}
