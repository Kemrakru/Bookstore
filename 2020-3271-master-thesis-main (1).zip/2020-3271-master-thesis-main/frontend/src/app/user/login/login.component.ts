import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { User } from "src/app/model/user.model";
import { UserService } from "src/services/user.service";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  constructor(private router: Router, private userService: UserService) {}

  loginEmail: "";
  loginPass: "";

  registerEmail: "";
  registerPass: "";
  registerPass2: "";
  registerName: "";

  ngOnInit() {
    if (localStorage.getItem("bookstore-user")) {
      this.router.navigate(["/home"]);
    }
  }

  login() {
    if (this.loginEmail && this.loginPass) {
      this.userService
        .login(this.loginEmail, this.loginPass)
        .subscribe((res: any) => {
          if (res.data[0].user) {
            localStorage.setItem(
              "bookstore-user",
              JSON.stringify(res.data[0].user)
            );
            this.router.navigate(["/profile"]);
          }
        });
    }
  }

  register() {
    if (this.registerPass === this.registerPass2) {
      let newUser: User = {
        _id: "0",
        address: "",
        country: "",
        email: this.registerEmail,
        fullname: "",
        name: this.registerName,
        password: this.registerPass,
        phone: "",
        state: "",
        town: "",
        type: "user",
        zip: "",
      };

      this.userService.register(newUser).subscribe((res: any) => {
        localStorage.setItem(
          "bookstore-user",
          JSON.stringify(res.data[0].user)
        );
        this.router.navigate(["/profile"]);
      });
    }
  }
}
