import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { BookService } from "src/services/book.service";
import { OrderService } from "src/services/order.service";
import { UserService } from "src/services/user.service";
import { Order } from "../model/order.model";
import { User } from "../model/user.model";

@Component({
  selector: "app-order",
  templateUrl: "./order.component.html",
  styleUrls: ["./order.component.css"],
})
export class OrderComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private orderService: OrderService,
    private userService: UserService,
    private router: Router
  ) {}

  order: Order;
  user: User = null;

  ngOnInit() {
    this.user = this.userService.getLoggedInUser();
    if (this.user == null) {
      this.router.navigate(["/login"]);
    }
    let orderId = this.route.snapshot.paramMap.get("id");
    this.orderService.getById(orderId).subscribe((order: Order) => {
      this.order = order;
      if (this.order.userId !== this.user._id && this.user.type !== "admin") {
        this.router.navigate(["/home"]);
      }
    });
  }

  getDateFormat(dateString: string) {
    return new Date(dateString).toLocaleDateString();
  }
}
