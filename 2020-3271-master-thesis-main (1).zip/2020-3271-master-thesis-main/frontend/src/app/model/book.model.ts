export const books: Array<Book> = [
  {
    _id: "1",
    title: "Beartown",
    cover: "book1.jpg",
    coverType: "Paperback",
    pages: 480,
    language: "English",
    authors: ["Fredrik Backman"],
    price: 15.99,
    categories: ["fiction", "crime", "thriller", "contemporary fiction"],
    description:
      "In a large Swedish forest, Beartown hides a dark secret...Cut-off from everywhere else it experiences the kind of isolation that tears people apart. And each year more and more of the town is swallowed by the forest. Then the town is offered a bright new future. But it is all put in jeopardy by a single, brutal act. It divides the town into those who think it should be hushed up and forgotten, and those who'll risk the future to see justice done. Who will speak up? Could you stand by and stay silent? Or would you risk everything for justice? Which side would you be on?",
    pubDate: "2018-10-01",
    rating: "4.27",
    ratingsNum: "",
    publisher: "Penguin Books Ltd",
    isbn: "9781405930208",
    available: true,
    amount: 5,
    sold: 0,
  },

  {
    _id: "2",
    title: "Verity",
    cover: "book2.jpg",
    coverType: "Paperback",
    pages: 367,
    language: "English",
    authors: ["Colleeen Hoover"],
    price: 13.99,
    categories: ["crime", "thriller"],
    description:
      "Lowen Ashleigh is a struggling writer on the brink of financial ruin when she accepts the job offer of a lifetime. Jeremy Crawford, husband of bestselling author Verity Crawford, has hired Lowen to complete the remaining books in a successful series his injured wife is unable to finish. Lowen arrives at the Crawford home, ready to sort through years of Verity's notes and outlines, hoping to find enough material to get her started. What Lowen doesn't expect to uncover in the chaotic office is an unfinished autobiography Verity never intended for anyone to read. Page after page of bone-chilling admissions, including Verity's recollection of the night their family was forever altered.",
    rating: "4.43",
    ratingsNum: "",
    pubDate: "2022-01-20",
    publisher: "Little, Brown Book Group",
    isbn: "9781408726600",
    available: false,
    amount: 5,
    sold: 0,
  },

  {
    _id: "3",
    title: "They both die in the end",
    coverType: "Paperback",
    pages: 355,
    language: "English",
    cover: "book3.jpg",
    authors: ["Adam Silvera"],
    price: 11.59,
    categories: ["children's fiction", "adventure"],
    rating: "3.88",
    ratingsNum: "",
    description:
      "A love story with a difference - an unforgettable tale of life, loss and making each day count in the INTERNATIONAL NO. 1 BESTSELLING book of TIKTOK fame, clocking up 80 million views and counting! The First to Die at the End, the prequel to They Both Die at the End, is now available to pre-order in hardback, coming October 2022. On September 5th, a little after midnight, Death-Cast calls Mateo Torrez and Rufus Emeterio to give them some bad news: they're going to die today. Mateo and Rufus are total strangers, but, for different reasons, they're both looking to make a new friend on their End Day. The good news: there's an app for that. It's called the Last Friend, and through it, Rufus and Mateo are about to meet up for one last great adventure - to live a lifetime in a single day.",
    pubDate: "2017-09-07",
    publisher: "Simon & Schuster Ltd",
    isbn: "9781471166204",
    available: true,
    amount: 0,
    sold: 0,
  },

  {
    _id: "4",
    title: "The Guest List",
    cover: "book4.jpg",
    coverType: "Paperback",
    pages: 400,
    language: "English",
    authors: ["Lucy Folly"],
    price: 12.19,
    categories: ["crime", "thriller", "horror"],
    rating: "3.85",
    ratingsNum: "",
    description:
      "On an island off the windswept Irish coast, guests gather for the wedding of the year - the marriage of Jules Keegan and Will Slater.<br> Old friends. <br>Past grudges.<br>Happy families.<br>Hidden jealousies.<br>Thirteen guests. <br>One body.",
    pubDate: "2020-09-03",
    publisher: "HarperCollins Publishers",
    isbn: "9780008297190",
    available: true,
    amount: 5,
    sold: 0,
  },

  {
    _id: "5",
    title: "Sleeping Beauties",
    cover: "book5.jpg",
    coverType: "Paperback",
    pages: 736,
    pubDate: "2017-09-26",
    publisher: "Hodder & Stoughton",
    isbn: "9781473665194",
    rating: "3.73",
    ratingsNum: "",
    description:
      "In this spectacular father/son collaboration, Stephen King and Owen King tell the highest of high-stakes stories: what might happen if women disappeared from the world of men? <br> All around the world, something is happening to women when they fall asleep; they become shrouded in a cocoon-like gauze. If awakened, if the gauze wrapping their bodies is disturbed, the women become feral and spectacularly violent...<br>In the small town of Dooling, West Virginia, the virus is spreading through a women's prison, affecting all the inmates except one. Soon, word spreads about the mysterious Evie, who seems able to sleep - and wake. Is she a medical anomaly or a demon to be slain? <br>The abandoned men, left to their increasingly primal devices, are fighting each other, while Dooling's Sheriff, Lila Norcross, is just fighting to stay awake. <br>And the sleeping women are about to open their eyes to a new world altogether...",
    language: "English",
    authors: ["Stephen King", "Owen King"],
    price: 10.59,
    categories: ["thriller", "horror"],
    available: true,
    amount: 5,
    sold: 0,
  },

  {
    _id: "6",
    title: "The Shining",
    cover: "shinning.jpg",
    coverType: "Paperback",
    pages: 688,
    rating: "4.25",
    ratingsNum: "",
    pubDate: "2020-02-07",
    publisher: "Random House USA Inc",
    isbn: "9780307743657",
    available: true,
    amount: 5,
    sold: 0,
    description:
      "#1 NEW YORK TIMES BESTSELLER - Before Doctor Sleep, there was The Shining, a classic of modern American horror from the undisputed master, Stephen King. <br>Jack Torrance's new job at the Overlook Hotel is the perfect chance for a fresh start. As the off-season caretaker at the atmospheric old hotel, he'll have plenty of time to spend reconnecting with his family and working on his writing. But as the harsh winter weather sets in, the idyllic location feels ever more remote . . . and more sinister. And the only one to notice the strange and terrible forces gathering around the Overlook is Danny Torrance, a uniquely gifted five-year-old.",
    language: "English",
    authors: ["Stephen King"],
    price: 13.18,
    categories: ["contemporary fiction", "thriller", "horror"],
  },

  {
    _id: "7",
    title: "Docteur Sleep",
    cover: "drsleep.jpg",
    coverType: "Paperback",
    pages: 688,
    pubDate: "2015-07-24",
    publisher: " Le Livre de Poche",
    isbn: "9782253183600",
    available: true,
    amount: 5,
    sold: 0,
    rating: "4.1",
    ratingsNum: "",
    description:
      "Danny Torrance, le petit garon, qui, dans Shining, sortait indemne de lincendie de lOverlook Palace, est devenu un adulte. Alcoolique et paum comme ltait son pre, il est maintenant aide-soignant dans un hospice o, grce aux pouvoirs surnaturels quil na pas perdus, il apaise la souffrance des mourants. On le surnomme Docteur Sleep. Lorsquil rencontre Abra, une fillette de 12 ans pourchasse par un trange groupe de voyageurs, Danny va retomber dans lhorreur. Commence alors une guerre pique entre le bien et le malPoint de normalit chez King, juste un voile dapparences jet sur la ralit du monde et un sillon, approfondi de livre en livre. Clmentine Goldszal, Les Inrockuptibles.King prouve encore une fois quil est un conteur diabolique, capable de nous blouir avec de la poudre de perlimpinpin comme de.",
    language: "French",
    authors: ["Stephen King"],
    price: 18.7,
    categories: ["thriller", "sci-fi"],
  },
];

export class Book {
  _id: string;
  title: string;
  available: boolean;
  amount: number;
  sold: number;
  cover: string;
  authors: Array<string>;
  categories: Array<string>;
  coverType: string;
  pages: number;
  pubDate: string;
  publisher: string;
  isbn: string;
  description: string;
  language: string;
  price: number;
  rating: string;
  ratingsNum: string;
}
