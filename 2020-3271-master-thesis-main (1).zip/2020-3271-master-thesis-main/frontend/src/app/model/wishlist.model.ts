import { Book, books } from "./book.model";

export const wishlistsArray: Wishlist[] = [
  {
    _id: "1",
    name: "My wishlist (default)",
    default: true,
    books: books.slice(0, 3),
    userId: "1",
  },
  {
    _id: "2",
    name: "Christmas wishes",
    books: books.slice(3),
    default: false,
    userId: "1",
  },
];

export class Wishlist {
  _id: string;
  name: string;
  books: Array<Book>;
  default: boolean;
  userId: string;
}
