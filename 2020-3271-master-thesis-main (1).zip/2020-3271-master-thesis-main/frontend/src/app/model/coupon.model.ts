export const coupons: Array<Coupon> = [
  {
    _id: "1",
    discount: 10,
    name: "Black Friday 20% off coupon",
    amount: 0,
    categories: ["thriller", "horror"],
    code: "BF22",
    dateTo: "2022-10-20",
    banner: "bf2022.png",
  },
];

export class Coupon {
  _id: string;
  code: string;
  dateTo: string;
  name: string;
  categories: string[];
  amount: number;
  banner: string;
  discount: number;
}
