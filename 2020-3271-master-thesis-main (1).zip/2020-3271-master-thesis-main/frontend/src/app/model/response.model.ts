export interface BookResponse {
  _id: string;
  isbn: string;
  title: string;
  available: boolean;
  amount: number;
  sold: number;
  cover: string;
  authors: string[];
  categories: string[];
  coverType: string;
  pages: number;
  pubDate: string;
  publisher: string;
  description: string;
  language: string;
  price: number;
  rating: string;
  ratingsNum: string;
}

export interface CouponResponse {
  _id: string;
  category: string;
  dateTo: string;
  name: string;
  code: string;
  amount: number;
}

export interface OrderResponse {
  _id: string;
  books: BookItem[];
  timestamp: string;
  userId?: string;
  price: number;
  paymentType: string;
  couponId: string;
  couponCode: string;
  email: string;
  phone: string;
  fullname: string;
  address: string;
  town: string;
  state?: string;
  zip: string;
  country: string;
}

export interface UserResponse {
  _id: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  fullname: string;
  address: string;
  town: string;
  state?: string;
  zip: string;
  country: string;
  type: string;
}

export interface WishlistResponse {
  _id: string;
  name: string;
  books: SimpleBook[];
  default: boolean;
  userId: string;
}

export interface BookItem {
  bookId: string;
  amount: number;
}

export interface SimpleBook {
  title: string;
  available: boolean;
  amount: number;
  cover: string;
  authors: string[];
  price: number;
}
