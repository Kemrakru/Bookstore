import { Book } from "./book.model";

export class BookItem {
  bookId: string;
  amount: number;
  book: Book;
}

export class Order {
  _id: string;
  books: Array<BookItem>;
  timestamp: string;
  userId: string;
  userInfo: any;
  price: number;
  paymentType: string;
  couponId: string;
  couponCode: string;
  sentDate: string;
}
