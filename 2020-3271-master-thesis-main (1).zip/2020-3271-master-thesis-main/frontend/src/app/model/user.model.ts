export const users: Array<User> = [
  {
    _id: "1",
    name: "Milica Nikolic",
    address: "Bungalovksa 3",
    country: "Serbia",
    email: "milicanikolica97@gmail.com",
    password: "Betonija1",
    fullname: "Milica Nikolic",
    phone: "0631652656",
    state: "",
    town: "Veliko Gradiste",
    type: "user",
    zip: "12220",
  },
  {
    _id: "2",
    name: "Ivana Nikolic",
    address: "Marsala Tita 96, Visnjica",
    country: "Serbia",
    email: "ivana@test.test",
    password: "Betonija1",
    fullname: "Ivana Nikolic",
    phone: "0631652656",
    state: "",
    town: "Belgrade",
    type: "user",
    zip: "11060",
  },
  {
    _id: "3",
    name: "Admin Admin",
    address: "Marsala Tita 96",
    country: "Serbia",
    email: "admin@test.test",
    password: "Betonija1",
    fullname: "Admin Nikolic",
    phone: "0631652656",
    state: "",
    town: "Belgrade",
    type: "admin",
    zip: "11060",
  },
];

export class User {
  _id: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  fullname: string;
  address: string;
  town: string;
  state: string;
  zip: string;
  country: string;
  type: string;
}
