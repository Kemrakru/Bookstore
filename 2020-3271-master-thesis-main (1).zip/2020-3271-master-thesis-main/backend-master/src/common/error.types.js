"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotImplemented = exports.GatewayTimeoutError = exports.UnauthorizedError = exports.ForbiddenError = exports.NotFoundError = exports.TooManyRequestsError = exports.InternalServerError = exports.bookstoreAPIError = exports.ValidationError = exports.ErrorCodes = void 0;
var ErrorCodes;
(function (ErrorCodes) {
    /**
     * Default Error codes
     */
    ErrorCodes["INTERNAL_SERVER_ERROR"] = "INTERNAL_SERVER_ERROR";
    ErrorCodes["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    ErrorCodes["TOO_MANY_REQUESTS"] = "TOO_MANY_REQUESTS";
    ErrorCodes["FORBIDDEN"] = "FORBIDDEN";
    ErrorCodes["UNAUTHORIZED"] = "UNAUTHORIZED";
    ErrorCodes["NOT_FOUND"] = "NOT_FOUND";
    ErrorCodes["VALIDATION_ERROR"] = "VALIDATION_ERROR";
    ErrorCodes["TIMEOUT"] = "TIMEOUT";
    /**
     * Case specific custom Error codes
     */
    ErrorCodes["EMAIL_EXISTS"] = "EMAIL_EXISTS";
    ErrorCodes["EMAIL_INVALID"] = "EMAIL_INVALID";
    ErrorCodes["RECAPTCHA_INVALID"] = "RECAPTCHA_INVALID";
    ErrorCodes["RECAPTCHA_BELOW_CRITERIA"] = "RECAPTCHA_BELOW_CRITERIA";
    ErrorCodes["TERMS_AND_COND_NOT_ACCEPTED"] = "TERMS_AND_COND_NOT_ACCEPTED";
})(ErrorCodes = exports.ErrorCodes || (exports.ErrorCodes = {}));
function ValidationError(messageOrParams, before) {
    if (typeof messageOrParams === 'string') {
        return new bookstoreAPIError({
            errorCode: ErrorCodes.VALIDATION_ERROR,
            statusCode: 400,
            message: messageOrParams
        });
    }
    else {
        return new bookstoreAPIError({
            errorCode: messageOrParams.errorCode || ErrorCodes.VALIDATION_ERROR,
            statusCode: 400,
            message: messageOrParams.message
        });
    }
}
exports.ValidationError = ValidationError;
class bookstoreAPIError extends Error {
    constructor(params, before) {
        super(params.message);
        this.params = params;
        this.before = before;
        this.id = genErrorId();
        this.date = new Date();
    }
    toJson(addBefore = false) {
        let json = Object.assign({ id: this.id, date: this.date.toISOString() }, this.params);
        if (addBefore) {
            json = this.maybeAddBefore(json);
        }
        return json;
    }
    maybeAddBefore(json) {
        if (this.before) {
            if (this.before instanceof bookstoreAPIError) {
                json.before = this.before.toJson(true);
            }
            else {
                json.before = this.before;
            }
        }
        return json;
    }
    send(res) {
        res.status(this.params.statusCode).json(this.toJson());
    }
}
exports.bookstoreAPIError = bookstoreAPIError;
function genErrorId() {
    return `error_${(Math.random() * 10).toString(36).substring(2)}_${Date.now()}`;
}
function InternalServerError(params = {}) {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.INTERNAL_SERVER_ERROR,
        statusCode: 500,
        message: params.message ? params.message : 'Internal Server Error'
    }, params.before);
}
exports.InternalServerError = InternalServerError;
function TooManyRequestsError() {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.TOO_MANY_REQUESTS,
        statusCode: 429,
        message: 'Please wait before sending more requests'
    });
}
exports.TooManyRequestsError = TooManyRequestsError;
function NotFoundError(message) {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.NOT_FOUND,
        statusCode: 404,
        message
    });
}
exports.NotFoundError = NotFoundError;
function ForbiddenError(message = 'Forbidden') {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.FORBIDDEN,
        statusCode: 403,
        message
    });
}
exports.ForbiddenError = ForbiddenError;
function UnauthorizedError(message = 'Unauthorized') {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.UNAUTHORIZED,
        statusCode: 401,
        message
    });
}
exports.UnauthorizedError = UnauthorizedError;
function GatewayTimeoutError(before) {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.TIMEOUT,
        statusCode: 504,
        message: 'Operation did not complete on time'
    }, before);
}
exports.GatewayTimeoutError = GatewayTimeoutError;
function NotImplemented(before) {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.NOT_IMPLEMENTED,
        statusCode: 501,
        message: 'Operation not implemented'
    }, before);
}
exports.NotImplemented = NotImplemented;
