import { Response } from "express";

export enum ErrorCodes {
    /**
     * Default Error codes
     */
    INTERNAL_SERVER_ERROR = 'INTERNAL_SERVER_ERROR',
    NOT_IMPLEMENTED = 'NOT_IMPLEMENTED',
    TOO_MANY_REQUESTS = 'TOO_MANY_REQUESTS',
    FORBIDDEN = 'FORBIDDEN',
    UNAUTHORIZED = 'UNAUTHORIZED',
    NOT_FOUND = 'NOT_FOUND',
    VALIDATION_ERROR = 'VALIDATION_ERROR',
    TIMEOUT = 'TIMEOUT',
    /**
     * Case specific custom Error codes
     */
    EMAIL_EXISTS = 'EMAIL_EXISTS',
    EMAIL_INVALID = 'EMAIL_INVALID',
    RECAPTCHA_INVALID = 'RECAPTCHA_INVALID',
    RECAPTCHA_BELOW_CRITERIA = 'RECAPTCHA_BELOW_CRITERIA',
    TERMS_AND_COND_NOT_ACCEPTED = 'TERMS_AND_COND_NOT_ACCEPTED'
}
export interface ValidationErrorParams {
    errorCode?: ErrorCodes,
    message: string
}
export function ValidationError(messageOrParams: string | ValidationErrorParams, before?: any): bookstoreAPIError {
    if (typeof messageOrParams === 'string') {
        return new bookstoreAPIError({
            errorCode: ErrorCodes.VALIDATION_ERROR,
            statusCode: 400,
            message: messageOrParams
    })
    } else {
        return new bookstoreAPIError({
            errorCode: messageOrParams.errorCode || ErrorCodes.VALIDATION_ERROR,
            statusCode: 400,
            message: messageOrParams.message
        })
    }
 
}

export interface bookstoreAPIErrorParams {
    statusCode: number,
    errorCode: string,
    message: string
}

export class bookstoreAPIError extends Error {
    public id: string;
    public date: Date;
    constructor(
        public params: bookstoreAPIErrorParams,
        public before?: Error | bookstoreAPIError
    ) {
        super(params.message);

        this.id = genErrorId();
        this.date = new Date();
    }

    toJson(addBefore: boolean = false): any {
        let json: any = {
            id: this.id,
            date: this.date.toISOString(),
            ...this.params
        }

        if (addBefore) {
            json = this.maybeAddBefore(json);
        }

        return json;
    }

    private maybeAddBefore(json: any) {
        if (this.before) {
            if (this.before instanceof bookstoreAPIError) {
                json.before = this.before.toJson(true);
            } else {
                json.before = this.before
            }
        }
        return json;
    }

    send(res: Response): void {
        res.status(this.params.statusCode).json(this.toJson());
    }
}

function genErrorId(): string {
    return `error_${(Math.random() * 10).toString(36).substring(2)}_${Date.now()}`;
}

export function InternalServerError(params: { message?: string, before?: any } = {}): bookstoreAPIError {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.INTERNAL_SERVER_ERROR,
        statusCode: 500,
        message: params.message ? params.message : 'Internal Server Error'
    }, params.before)
}

export function TooManyRequestsError(): bookstoreAPIError {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.TOO_MANY_REQUESTS,
        statusCode: 429,
        message: 'Please wait before sending more requests'
    })
}


export function NotFoundError(message: string): bookstoreAPIError {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.NOT_FOUND,
        statusCode: 404,
        message
    })
}

export function ForbiddenError(message: string = 'Forbidden'): bookstoreAPIError {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.FORBIDDEN,
        statusCode: 403,
        message
    })
}

export function UnauthorizedError(message: string = 'Unauthorized'): bookstoreAPIError {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.UNAUTHORIZED,
        statusCode: 401,
        message
    })
}

export function GatewayTimeoutError(before?: any): bookstoreAPIError {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.TIMEOUT,
        statusCode: 504,
        message: 'Operation did not complete on time'
    }, before)
}

export function NotImplemented(before?: any): bookstoreAPIError {
    return new bookstoreAPIError({
        errorCode: ErrorCodes.NOT_IMPLEMENTED,
        statusCode: 501,
        message: 'Operation not implemented'
    }, before)
}