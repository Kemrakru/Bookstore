"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailService = void 0;
const inversify_1 = require("inversify");
var nodemailer = require("nodemailer");
let MailService = class MailService {
    constructor() {
        this.transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: "djmarkos97@gmail.com",
                pass: "zkzaoepclsedelej",
            },
        });
    }
    sendConfirmationEmail(order, to = "") {
        var mailOptions = {};
        if (to !== "") {
            mailOptions = {
                from: "Bookstore <djmarkos97@gmail.com>",
                to: to,
                subject: "Successful order",
                html: `Dear ${order.userInfo.fullname}, <br> <br> your order, with OrderId: ${order._id}, has been created. To check the details of it, please go to this <a href='http://localhost:4200/order/${order._id}'>Link.</a> <br> Sincerely <br> <br> Your <a href='http://localhost:4200/home'>Bookstore</a>`,
            };
        }
        else {
            mailOptions = {
                from: "Bookstore <djmarkos97@gmail.com>",
                to: "djdjm97@gmail.com",
                subject: "Successful order for user " + order.userInfo.fullname,
                html: `You have new order in your orders. Go to the orders page on the <a href='http://localhost:4200/order/${order._id}'>Link</a>`,
            };
        }
        this.transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            }
            else {
                console.log("Email sent: " + info.response);
            }
        });
    }
    sendOrderSentEmail(order, to = "") {
        var mailOptions = {};
        mailOptions = {
            from: "Bookstore <djmarkos97@gmail.com>",
            to: to,
            subject: "Order sent",
            html: `Dear ${order.userInfo.fullname}, <br> <br> your order of ${order.price} USD, has been sent and is on its way. To check the details of it, please go to this <a href='http://localhost:4200/order/${order._id}'>Link.</a> <br>  <br> Sincerely <br> Your <a href='http://localhost:4200/home'>Bookstore</a>`,
        };
        this.transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            }
            else {
                console.log("Email sent: " + info.response);
            }
        });
    }
};
MailService = __decorate([
    (0, inversify_1.injectable)()
], MailService);
exports.MailService = MailService;
