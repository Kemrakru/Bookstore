"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookServiceImpl = void 0;
const crypto_1 = require("crypto");
const inversify_1 = require("inversify");
const error_types_1 = require("../common/error.types");
const user_model_1 = require("../models/user.model");
const base_service_1 = require("./base.service");
const cheerio = require("cheerio");
const axios = require("axios");
let BookServiceImpl = class BookServiceImpl extends base_service_1.BaseServiceImpl {
    constructor(dbConnector, bookRepo) {
        super();
        this.dbConnector = dbConnector;
        this.repository = bookRepo;
    }
    async create(newBookData, userType) {
        if (userType === user_model_1.UserType.ADMIN) {
            return await this.createWithoutCheck(newBookData);
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to create book`);
        }
    }
    async delete(bookId, userType) {
        if (userType === user_model_1.UserType.ADMIN) {
            const isBookNotInStore = await this.isBookNotInStore(bookId);
            if (isBookNotInStore) {
                await this.deleteWithoutCheck(bookId);
            }
            else {
                throw (0, error_types_1.ValidationError)(`Can't remove book that still has copies in stock`);
            }
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to remove book`);
        }
    }
    async patch(bookId, data, userType) {
        if (userType === user_model_1.UserType.ADMIN) {
            await this.patchWithoutCheck(bookId, data);
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to change book`);
        }
    }
    async patchWithoutCheck(bookId, data) {
        const operations = [this.patchRootProperties(bookId, data)];
        await Promise.all(operations);
    }
    async deleteWithoutCheck(bookId) {
        const isBookDeletable = await this.isBookNotSold(bookId);
        if (isBookDeletable) {
            await this.deleteFromDB(bookId);
        }
        else {
            await this.makeUnavailabe(bookId);
        }
    }
    async createWithoutCheck(newBookData) {
        const bookId = (0, crypto_1.randomBytes)(20).toString("hex");
        const book = {
            _id: bookId,
            isbn: newBookData.isbn,
            title: newBookData.title,
            available: newBookData.available,
            amount: newBookData.amount,
            sold: newBookData.sold,
            categories: newBookData.categories,
            cover: newBookData.cover,
            authors: newBookData.authors,
            coverType: newBookData.coverType,
            pages: newBookData.pages,
            pubDate: newBookData.pubDate,
            publisher: newBookData.publisher,
            description: newBookData.description,
            language: newBookData.language,
            price: newBookData.price,
            rating: newBookData.rating,
            ratingsNum: newBookData.ratingsNum,
        };
        const [result] = await Promise.all([this.repository.insert(book)]);
        return result;
    }
    patchRootProperties(bookId, data) {
        const changes = this.buildPatchChanges(data);
        if (!changes) {
            // no changes, nothing to be done here
            return;
        }
        else {
            return this.repository.update({
                _id: bookId,
            }, {
                $set: Object.assign({}, changes),
            });
        }
    }
    async isBookNotSold(bookId) {
        const bookInDB = await this.repository.findOne({ bookId });
        if (bookInDB) {
            return bookInDB.sold === 0;
        }
    }
    async isBookNotInStore(bookId) {
        const bookInDB = await this.repository.findOne({ bookId });
        if (bookInDB) {
            return bookInDB.amount === 0;
        }
    }
    async deleteFromDB(bookId) {
        await this.dbConnector.transaction(async (session) => {
            await Promise.all([
                this.repository.deleteOne({
                    _id: bookId,
                }, { session }),
            ]);
        });
    }
    async makeUnavailabe(bookId) {
        const book = await this.repository.findOne({ bookId });
        await this.dbConnector.transaction(async (session) => {
            await Promise.all([
                this.repository.update(Object.assign({ _id: bookId, available: false }, book), { session }),
            ]);
        });
    }
    getKeyFilter(param) {
        return {
            _id: param,
        };
    }
    async getBestSellingBooks() {
        return await this.repository.bestselling();
    }
    async getOne(id) {
        let book = await super.getOne(id);
        if (book) {
            const title = book.title.toLowerCase().replace(" ", "+");
            const { data } = await axios.get("https://www.goodreads.com/search?q=" + title);
            const $ = cheerio.load(data);
            $("tr").each(function (i, item) {
                if ($(".bookTitle", item)
                    .text()
                    .trim()
                    .toLowerCase()
                    .includes(book.title.trim().toLowerCase())) {
                    if ($(".authorName", item)
                        .text()
                        .trim()
                        .toLowerCase()
                        .includes(book.authors[0].trim().toLowerCase())) {
                        console.log($(".minirating", item).text());
                        let ratingsString = $(".minirating", item).text();
                        let ratingsArray = ratingsString.trim().split(" avg rating");
                        book.rating = ratingsArray[0];
                        book.ratingsNum = ratingsArray[1];
                        return false;
                    }
                }
            });
        }
        return book;
    }
};
BookServiceImpl = __decorate([
    (0, inversify_1.injectable)()
], BookServiceImpl);
exports.BookServiceImpl = BookServiceImpl;
