"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CouponServiceImpl = void 0;
const crypto_1 = require("crypto");
const inversify_1 = require("inversify");
const error_types_1 = require("../common/error.types");
const user_model_1 = require("../models/user.model");
const order_repository_1 = require("../repositories/order.repository");
const base_service_1 = require("./base.service");
let CouponServiceImpl = class CouponServiceImpl extends base_service_1.BaseServiceImpl {
    constructor(dbConnector, couponRepo) {
        super();
        this.dbConnector = dbConnector;
        this.repository = couponRepo;
        this.orderRepository = new order_repository_1.OrderRepositoryImpl(dbConnector);
    }
    async create(newCouponData, userType) {
        if (userType === user_model_1.UserType.ADMIN) {
            return await this.createWithoutCheck(newCouponData);
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to create coupon`);
        }
    }
    async delete(couponId, userType) {
        if (userType === user_model_1.UserType.ADMIN) {
            await this.deleteWithoutCheck(couponId);
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to remove coupon`);
        }
    }
    async patch(couponId, data, userType) {
        if (userType === user_model_1.UserType.ADMIN) {
            await this.patchWithoutCheck(couponId, data);
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to change coupon`);
        }
    }
    async patchWithoutCheck(couponId, data) {
        const operations = [
            this.patchRootProperties(couponId, data)
        ];
        await Promise.all(operations);
    }
    async deleteWithoutCheck(couponId) {
        await this.deleteFromDB(couponId);
    }
    async createWithoutCheck(newCouponData) {
        const couponId = (0, crypto_1.randomBytes)(20).toString('hex');
        const coupon = {
            _id: couponId,
            categories: newCouponData.categories,
            dateTo: newCouponData.dateTo,
            name: newCouponData.name,
            code: newCouponData.code,
            amount: newCouponData.amount,
            banner: newCouponData.banner,
            discount: newCouponData.discount
        };
        const [result] = await Promise.all([
            this.repository.insert(coupon)
        ]);
        return result;
    }
    patchRootProperties(couponId, data, session) {
        const changes = this.buildPatchChanges(data);
        if (!changes) {
            // no changes, nothing to be done here
            return;
        }
        else {
            return this.repository.update({
                _id: couponId
            }, {
                $set: Object.assign({}, changes)
            }, { session });
        }
    }
    async deleteFromDB(couponId) {
        await Promise.all([
            this.repository.deleteOne({
                _id: couponId
            })
        ]);
    }
    getKeyFilter(param) {
        return {
            _id: param
        };
    }
    async getActive() {
        let coupons = await this.repository.find({});
        let orders = await this.orderRepository.find({});
        return coupons.filter((c) => {
            let dateCheck = c.dateTo ? (new Date(c.dateTo) > new Date()) : true;
            let amountCheck = true;
            if (c.amount) {
                let ordersCount = orders.filter(o => o.couponId === c._id).length;
                if (ordersCount) {
                    amountCheck = c.amount > ordersCount;
                }
            }
            return dateCheck && amountCheck;
        });
    }
};
CouponServiceImpl = __decorate([
    (0, inversify_1.injectable)()
], CouponServiceImpl);
exports.CouponServiceImpl = CouponServiceImpl;
