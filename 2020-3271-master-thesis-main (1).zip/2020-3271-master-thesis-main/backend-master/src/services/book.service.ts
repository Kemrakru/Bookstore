import { randomBytes } from "crypto";
import { inject, injectable } from "inversify";
import { ClientSession, Filter } from "mongodb";
import { ValidationError } from "../common/error.types";
import { Book, NewBook, PatchBook } from "../models/book.model";
import { UserType } from "../models/user.model";
import { MongoDBConnector } from "../mongodb.connector";
import { BookRepository } from "../repositories/book.repository";
import { BaseServiceImpl } from "./base.service";

const cheerio = require("cheerio");
const axios = require("axios");

export interface BookService {
  create(newBookData: NewBook, userType: string): Promise<Book>;
  delete(bookId: string, userType: string): Promise<void>;
  patch(bookId: string, data: PatchBook, userType: string): Promise<void>;
  getBestSellingBooks(): Promise<Book[]>;
}

@injectable()
export class BookServiceImpl
  extends BaseServiceImpl<Book>
  implements BookService
{
  private dbConnector: MongoDBConnector;
  protected repository: BookRepository;
  constructor(dbConnector: MongoDBConnector, bookRepo: BookRepository) {
    super();
    this.dbConnector = dbConnector;
    this.repository = bookRepo;
  }
  async create(newBookData: NewBook, userType: string): Promise<Book> {
    if (userType === UserType.ADMIN) {
      return await this.createWithoutCheck(newBookData);
    } else {
      throw ValidationError(`Insufficient access to create book`);
    }
  }
  async delete(bookId: string, userType: string): Promise<void> {
    if (userType === UserType.ADMIN) {
      const isBookNotInStore = await this.isBookNotInStore(bookId);
      if (isBookNotInStore) {
        await this.deleteWithoutCheck(bookId);
      } else {
        throw ValidationError(
          `Can't remove book that still has copies in stock`
        );
      }
    } else {
      throw ValidationError(`Insufficient access to remove book`);
    }
  }
  async patch(
    bookId: string,
    data: PatchBook,
    userType: string
  ): Promise<void> {
    if (userType === UserType.ADMIN) {
      await this.patchWithoutCheck(bookId, data);
    } else {
      throw ValidationError(`Insufficient access to change book`);
    }
  }
  async patchWithoutCheck(bookId: string, data: PatchBook): Promise<void> {
    const operations = [this.patchRootProperties(bookId, data)];

    await Promise.all(operations);
  }
  async deleteWithoutCheck(bookId: string): Promise<void> {
    const isBookDeletable = await this.isBookNotSold(bookId);
    if (isBookDeletable) {
      await this.deleteFromDB(bookId);
    } else {
      await this.makeUnavailabe(bookId);
    }
  }
  async createWithoutCheck(newBookData: NewBook): Promise<Book> {
    const bookId = randomBytes(20).toString("hex");

    const book: Book = {
      _id: bookId,
      isbn: newBookData.isbn,
      title: newBookData.title,
      available: newBookData.available,
      amount: newBookData.amount,
      sold: newBookData.sold,
      categories: newBookData.categories,
      cover: newBookData.cover,
      authors: newBookData.authors,
      coverType: newBookData.coverType,
      pages: newBookData.pages,
      pubDate: newBookData.pubDate,
      publisher: newBookData.publisher,
      description: newBookData.description,
      language: newBookData.language,
      price: newBookData.price,
      rating: newBookData.rating,
      ratingsNum: newBookData.ratingsNum,
    };

    const [result] = await Promise.all([this.repository.insert(book)]);

    return result;
  }

  private patchRootProperties(bookId: string, data: PatchBook): Promise<void> {
    const changes = this.buildPatchChanges<PatchBook, Book>(data);

    if (!changes) {
      // no changes, nothing to be done here
      return;
    } else {
      return this.repository.update(
        {
          _id: bookId,
        },
        {
          $set: {
            ...changes,
          },
        }
      );
    }
  }
  private async isBookNotSold(bookId: string): Promise<boolean> {
    const bookInDB = await this.repository.findOne({ bookId });
    if (bookInDB) {
      return bookInDB.sold === 0;
    }
  }
  private async isBookNotInStore(bookId: string): Promise<boolean> {
    const bookInDB = await this.repository.findOne({ bookId });
    if (bookInDB) {
      return bookInDB.amount === 0;
    }
  }
  private async deleteFromDB(bookId: string): Promise<void> {
    await this.dbConnector.transaction(
      async (session: ClientSession): Promise<void> => {
        await Promise.all([
          this.repository.deleteOne(
            {
              _id: bookId,
            },
            { session }
          ),
        ]);
      }
    );
  }
  private async makeUnavailabe(bookId: string): Promise<void> {
    const book = await this.repository.findOne({ bookId });
    await this.dbConnector.transaction(
      async (session: ClientSession): Promise<void> => {
        await Promise.all([
          this.repository.update(
            {
              _id: bookId,
              available: false,
              ...book,
            },
            { session }
          ),
        ]);
      }
    );
  }
  protected getKeyFilter(param: string): Filter<Book> {
    return {
      _id: param,
    };
  }
  async getBestSellingBooks(): Promise<Book[]> {
    return await this.repository.bestselling();
  }
  async getOne(id: string): Promise<Book> {
    let book = await super.getOne(id);
    if (book) {
      const title = book.title.toLowerCase().replace(" ", "+");
      const { data } = await axios.get(
        "https://www.goodreads.com/search?q=" + title
      );
      const $ = cheerio.load(data);
      $("tr").each(function (i, item) {
        if (
          $(".bookTitle", item)
            .text()
            .trim()
            .toLowerCase()
            .includes(book.title.trim().toLowerCase())
        ) {
          if (
            $(".authorName", item)
              .text()
              .trim()
              .toLowerCase()
              .includes(book.authors[0].trim().toLowerCase())
          ) {
            console.log($(".minirating", item).text());
            let ratingsString = $(".minirating", item).text();
            let ratingsArray = ratingsString.trim().split(" avg rating");
            book.rating = ratingsArray[0];
            book.ratingsNum = ratingsArray[1];
            return false;
          }
        }
      });
    }
    return book;
  }
}
