import { injectable } from "inversify";
import { Order } from "../models/order.model";
var nodemailer = require("nodemailer");

@injectable()
export class MailService {
  private transporter: any;

  constructor() {
    this.transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "djmarkos97@gmail.com",
        pass: "zkzaoepclsedelej",
      },
    });
  }

  sendConfirmationEmail(order: Order, to: string = "") {
    var mailOptions: any = {};
    if (to !== "") {
      mailOptions = {
        from: "Bookstore <djmarkos97@gmail.com>",
        to: to,
        subject: "Successful order",
        html: `Dear ${order.userInfo.fullname}, <br> <br> your order, with OrderId: ${order._id}, has been created. To check the details of it, please go to this <a href='http://localhost:4200/order/${order._id}'>Link.</a> <br> Sincerely <br> <br> Your <a href='http://localhost:4200/home'>Bookstore</a>`,
      };
    } else {
      mailOptions = {
        from: "Bookstore <djmarkos97@gmail.com>",
        to: "djdjm97@gmail.com",
        subject: "Successful order for user " + order.userInfo.fullname,
        html: `You have new order in your orders. Go to the orders page on the <a href='http://localhost:4200/order/${order._id}'>Link</a>`,
      };
    }

    this.transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log(error);
      } else {
        console.log("Email sent: " + info.response);
      }
    });
  }

  sendOrderSentEmail(order: Order, to: string = "") {
    var mailOptions: any = {};

    mailOptions = {
      from: "Bookstore <djmarkos97@gmail.com>",
      to: to,
      subject: "Order sent",
      html: `Dear ${order.userInfo.fullname}, <br> <br> your order of ${order.price} USD, has been sent and is on its way. To check the details of it, please go to this <a href='http://localhost:4200/order/${order._id}'>Link.</a> <br>  <br> Sincerely <br> Your <a href='http://localhost:4200/home'>Bookstore</a>`,
    };

    this.transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log(error);
      } else {
        console.log("Email sent: " + info.response);
      }
    });
  }
}
