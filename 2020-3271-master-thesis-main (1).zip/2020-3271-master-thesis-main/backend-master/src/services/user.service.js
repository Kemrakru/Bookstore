"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserServiceImpl = void 0;
const crypto_1 = require("crypto");
const inversify_1 = require("inversify");
const error_types_1 = require("../common/error.types");
const user_model_1 = require("../models/user.model");
const base_service_1 = require("./base.service");
let UserServiceImpl = class UserServiceImpl extends base_service_1.BaseServiceImpl {
    constructor(dbConnector, userRepo) {
        super();
        this.loggedInUser = null;
        this.dbConnector = dbConnector;
        this.repository = userRepo;
    }
    async create(newUserData) {
        return await this.createWithoutCheck(newUserData);
    }
    async delete(userId, userType) {
        if (userType === user_model_1.UserType.USER) {
            await this.deleteWithoutCheck(userId);
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to remove user`);
        }
    }
    async patch(userId, data, authenticatedUser) {
        if (authenticatedUser._id === userId) {
            await this.patchWithoutCheck(userId, data);
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to change user`);
        }
    }
    async patchWithoutCheck(userId, data) {
        const operations = [
            this.patchRootProperties(userId, data)
        ];
        await Promise.all(operations);
    }
    async deleteWithoutCheck(userId) {
        await this.deleteFromDB(userId);
    }
    async createWithoutCheck(newUserData) {
        const userId = (0, crypto_1.randomBytes)(20).toString('hex');
        const user = Object.assign({ _id: userId, name: newUserData.name, email: newUserData.email, password: newUserData.password, phone: newUserData.phone, fullname: newUserData.fullname, address: newUserData.address, town: newUserData.town, zip: newUserData.zip, country: newUserData.country, type: newUserData.type }, newUserData);
        return await this.repository.insert(user);
    }
    async login(email, password) {
        const [result] = await Promise.all([
            this.repository.findOne({
                email,
                password
            })
        ]);
        this.loggedInUser = result;
        return result;
    }
    async authenticateUser(userId) {
        const user = await this.repository.findOne({ '_id': userId });
        if (user) {
            return user;
        }
        else {
            throw (0, error_types_1.ValidationError)(`Bad access`);
        }
    }
    async patchRootProperties(userId, data) {
        const changes = this.buildPatchChanges(data);
        if (!changes) {
            // no changes, nothing to be done here
            return;
        }
        else {
            return await this.repository.update({
                _id: userId
            }, {
                $set: Object.assign({}, changes)
            });
        }
    }
    async deleteFromDB(userId) {
        await this.dbConnector.transaction(async (session) => {
            await Promise.all([
                this.repository.deleteOne({
                    _id: userId
                }, { session })
            ]);
        });
    }
    getKeyFilter(param) {
        return {
            _id: param
        };
    }
};
UserServiceImpl = __decorate([
    (0, inversify_1.injectable)()
], UserServiceImpl);
exports.UserServiceImpl = UserServiceImpl;
