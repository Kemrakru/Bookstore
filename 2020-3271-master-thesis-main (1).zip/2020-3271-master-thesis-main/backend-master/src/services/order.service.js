"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderServiceImpl = void 0;
const crypto_1 = require("crypto");
const inversify_1 = require("inversify");
const book_repository_1 = require("../repositories/book.repository");
const base_service_1 = require("./base.service");
let OrderServiceImpl = class OrderServiceImpl extends base_service_1.BaseServiceImpl {
    constructor(dbConnector, orderRepo) {
        super();
        this.dbConnector = dbConnector;
        this.repository = orderRepo;
        this.bookRepository = new book_repository_1.BookRepositoryImpl(dbConnector);
    }
    async create(newOrderData) {
        return await this.createWithoutCheck(newOrderData);
    }
    async createWithoutCheck(newOrderData) {
        const orderId = (0, crypto_1.randomBytes)(20).toString('hex');
        const order = Object.assign({ _id: orderId, books: newOrderData.books, timestamp: newOrderData.timestamp, price: newOrderData.price, paymentType: newOrderData.paymentType, couponId: newOrderData.couponId, couponCode: newOrderData.couponCode, userInfo: newOrderData.userInfo }, newOrderData);
        const [result] = await Promise.all([
            this.repository.insert(order)
        ]);
        for (let i = 0; i < order.books.length; i++) {
            await this.bookRepository.update({ _id: order.books[i].bookId }, { $inc: { sold: order.books[i].amount, amount: -1 } });
        }
        return result;
    }
    getKeyFilter(param) {
        return {
            _id: param
        };
    }
    async getAll(params) {
        return await this.repository.find(params);
    }
    async getOne(orderId) {
        let order = await super.getOne(orderId);
        for (let i = 0; i < order.books.length; i++) {
            order.books[i].book = await this.bookRepository.findOne({ _id: order.books[i].bookId });
        }
        console.log(order);
        return order;
    }
    async send(orderId, date) {
        this.repository.update({ _id: orderId }, { $set: { sentDate: date } });
    }
};
OrderServiceImpl = __decorate([
    (0, inversify_1.injectable)()
], OrderServiceImpl);
exports.OrderServiceImpl = OrderServiceImpl;
