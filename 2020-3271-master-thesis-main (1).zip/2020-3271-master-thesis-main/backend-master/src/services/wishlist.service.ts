import { randomBytes } from "crypto";
import { injectable } from "inversify";
import { ClientSession, Filter } from "mongodb";
import { ValidationError } from "../common/error.types";
import { SimpleBook } from "../models/book.model";
import { UserType } from "../models/user.model";
import { NewWishlist, PatchWishlist, Wishlist } from "../models/wishlist.model";
import { MongoDBConnector } from "../mongodb.connector";
import { WishlistRepository } from "../repositories/wishlist.repository";
import { BaseServiceImpl } from "./base.service";

export interface WishlistService {
    create(newWishlistData:NewWishlist, userType:string): Promise<Wishlist>
    delete(wishlistId: string, userId:string, userType:string): Promise<void>
    patch(wishlistId:string, data: PatchWishlist, userId:string, userType:string): Promise<void>
    addBook(wishlistId:string, data: SimpleBook, userId:string, userType:string): Promise<void>
}

@injectable()
export class WishlistServiceImpl extends BaseServiceImpl<Wishlist> implements WishlistService {
    private dbConnector: MongoDBConnector;
    protected repository: WishlistRepository;
    constructor(
        dbConnector: MongoDBConnector,
        wishlistRepo: WishlistRepository,
    ) {
        super();
        this.repository = wishlistRepo;
        this.dbConnector = dbConnector;
    }
    async addBook(wishlistId: string, data: SimpleBook, userId: string, userType: string): Promise<void> 
    {
        if (userType === UserType.USER) 
        {
            const list = await this.getOne(wishlistId);
            if(list.userId === userId)
            {
                const [result] = await Promise.all([
                    this.repository.update(
                        { _id: wishlistId },
                        { $push: { books: data } }
                     )
                ]);
                return result;
            }
            else
            {
                throw ValidationError(`No access to change wishlist`);
            }
        }
        else
        {
            throw ValidationError(`Insufficient access to change wishlist`);
        }
    }
    async removeBook(wishlistId: string, bookId: string, userId: string, userType: string): Promise<void> 
    {
        if (userType === UserType.USER) 
        {
            const list = await this.getOne(wishlistId);
            if(list.userId === userId)
            {
                const [result] = await Promise.all([
                    this.repository.update(
                        { _id: wishlistId },
                        { $pull: { books: {_id: bookId} } }
                     )
                ]);
                return result;
            }
            else
            {
                throw ValidationError(`No access to change wishlist`);
            }
        }
        else
        {
            throw ValidationError(`Insufficient access to change wishlist`);
        }
    }
    async create(newWishlistData:NewWishlist, userType:string): Promise<Wishlist>
    {
        if (userType === UserType.USER) {
            return await this.createWithoutCheck(newWishlistData);
        }else{
            throw ValidationError(`Insufficient access to create wishlist`);
        }
    }
    async delete(wishlistId: string, userId:string, userType:string): Promise<void>
    {
        if (userType === UserType.USER) {
            const list = await this.getOne(wishlistId);
            if(list.userId === userId){
                if(list.default === false){
                    await this.deleteWithoutCheck(wishlistId);
                }else{
                    throw ValidationError(`Cannot remove default wishlist`);
                }
            }else{
                throw ValidationError(`No access to remove wishlist`);
            }
        }else{
            throw ValidationError(`Insufficient access to remove wishlist`);
        }
    }
    async patch(wishlistId:string, data: PatchWishlist, userId:string, userType:string): Promise<void>
    {
        if (userType === UserType.USER) {
            const list = await this.getOne(wishlistId);
            if(list.userId === userId){
                if(list.default === false){
                    await this.patchWithoutCheck(wishlistId, data);
                }else{
                    throw ValidationError(`Cannot change default wishlist`);
                }
            }else{
                throw ValidationError(`No access to change wishlist`);
            }
        }else{
            throw ValidationError(`Insufficient access to change wishlist`);
        }
    }

    async patchWithoutCheck(wishlistId: string, data: PatchWishlist): Promise<void> 
    {
        const operations = [
            this.patchRootProperties(
                wishlistId,
                data
            )
        ];

        await Promise.all(operations);        
    }
    async deleteWithoutCheck(wishlistId: string): Promise<void> {
        await this.deleteFromDB(wishlistId);
    }
    async createWithoutCheck(newWishlistData:NewWishlist): Promise<Wishlist> 
    {
        const wishlistId = randomBytes(20).toString('hex');

        const wishlist: Wishlist = {
            _id: wishlistId,
            name:newWishlistData.name,
            books:newWishlistData.books,
            default:newWishlistData.default,
            userId:newWishlistData.userId,
        }

        const [result] = await Promise.all([
            this.repository.insert(wishlist)
        ]);

        return result;
    }

    private patchRootProperties(wishlistId: string, data: PatchWishlist, session?: ClientSession): Promise<void> 
    {
        const changes = this.buildPatchChanges<PatchWishlist, Wishlist>(data);
        if (!changes) {
            // no changes, nothing to be done here
            return;
        } else {
            return this.repository.update({
                _id: wishlistId
            }, {
                $set: {
                    ...changes
                }
            }, { session });
        }
    }
    private async deleteFromDB(wishlistId: string): Promise<void> 
    {
        await Promise.all([
            this.repository.deleteOne({
                _id: wishlistId
            })
        ])  
    }
    protected getKeyFilter(param:string): Filter<Wishlist> 
    {
        return {
            _id: param
        }
    }
    public async getByUserId(userId:string): Promise<Wishlist[]> 
    {
        const [result] = await Promise.all([
            this.repository.find({userId: userId})
        ]);
        return result;
    }
}