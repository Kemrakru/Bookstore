import { randomBytes } from "crypto";
import { inject, injectable } from "inversify";
import { ClientSession, Filter } from "mongodb";
import { ValidationError } from "../common/error.types";
import { Coupon, NewCoupon, PatchCoupon } from "../models/coupon.model";
import { UserType } from "../models/user.model";
import { MongoDBConnector } from "../mongodb.connector";
import { CouponRepository } from "../repositories/coupon.repository";
import { OrderRepository, OrderRepositoryImpl } from "../repositories/order.repository";
import { BaseServiceImpl } from "./base.service";

export interface CouponService {
    create(newCouponData:NewCoupon, userType:string): Promise<Coupon>
    delete(couponId: string, userType:string): Promise<void>
    patch(couponId:string, data: PatchCoupon, userType:string): Promise<void>
}

@injectable()
export class CouponServiceImpl extends BaseServiceImpl<Coupon> implements CouponService {
    private dbConnector: MongoDBConnector;
    protected repository: CouponRepository;
    protected orderRepository: OrderRepository;
    constructor(
        dbConnector: MongoDBConnector,
        couponRepo: CouponRepository,
    ) {
        super();
        this.dbConnector = dbConnector; 
        this.repository = couponRepo; 
        this.orderRepository = new OrderRepositoryImpl(dbConnector); 
    }
    async create(newCouponData:NewCoupon, userType:string): Promise<Coupon>
    {
        if (userType === UserType.ADMIN) 
        {
            return await this.createWithoutCheck(newCouponData);
        }
        else
        {
            throw ValidationError(`Insufficient access to create coupon`);
        }
    }
    async delete(couponId: string, userType:string): Promise<void>
    {
        if (userType === UserType.ADMIN) 
        {
            await this.deleteWithoutCheck(couponId);
        }
        else
        {
            throw ValidationError(`Insufficient access to remove coupon`);
        }
    }
    async patch(couponId:string, data: PatchCoupon, userType:string): Promise<void>
    {
        if (userType === UserType.ADMIN) 
        {
            await this.patchWithoutCheck(couponId, data);
        }
        else
        {
            throw ValidationError(`Insufficient access to change coupon`);
        }
    }
    async patchWithoutCheck(couponId: string, data: PatchCoupon): Promise<void> 
    {
        const operations = [
            this.patchRootProperties(
                couponId,
                data
            )
        ];

        await Promise.all(operations);
    }
    async deleteWithoutCheck(couponId: string): Promise<void> 
    {
        await this.deleteFromDB(couponId);
    }
    async createWithoutCheck(newCouponData:NewCoupon): Promise<Coupon> 
    {
        const couponId = randomBytes(20).toString('hex');

        const coupon: Coupon = {
            _id: couponId,
            categories:newCouponData.categories,
            dateTo:newCouponData.dateTo,
            name:newCouponData.name,
            code:newCouponData.code,
            amount:newCouponData.amount,
            banner:newCouponData.banner,
            discount:newCouponData.discount
        }

        const [result] = await Promise.all([
            this.repository.insert(coupon)
        ]);

        return result;
    }

    private patchRootProperties(couponId: string, data: PatchCoupon, session?: ClientSession): Promise<void> 
    {
        const changes = this.buildPatchChanges<PatchCoupon, Coupon>(data);
        if (!changes) 
        {
            // no changes, nothing to be done here
            return;
        } 
        else 
        {
            return this.repository.update({
                _id: couponId
            }, {
                $set: {
                    ...changes
                }
            }, { session });
        }
    }
    private async deleteFromDB(couponId: string): Promise<void> 
    {
        await Promise.all([
            this.repository.deleteOne({
                _id: couponId
            })
        ])
    }
    protected getKeyFilter(param:string): Filter<Coupon> 
    {
        return {
            _id: param
        }
    }
    async getActive()
    {
        let coupons = await this.repository.find({});
        let orders = await this.orderRepository.find({});
        return coupons.filter((c:Coupon) => 
            {
                let dateCheck=c.dateTo? (new Date(c.dateTo)> new Date()) : true;
                let amountCheck=true;
                if(c.amount)
                {
                    let ordersCount=orders.filter(o=>o.couponId===c._id).length;
                    if(ordersCount)
                    {
                        amountCheck = c.amount > ordersCount;
                    }
                }
                return dateCheck && amountCheck;
            })
    }
}