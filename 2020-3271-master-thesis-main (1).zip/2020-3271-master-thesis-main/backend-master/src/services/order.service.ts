import { randomBytes } from "crypto";
import { inject, injectable } from "inversify";
import { ClientSession, Filter } from "mongodb";
import { ValidationError } from "../common/error.types";
import { SimpleBook } from "../models/book.model";
import { Order, NewOrder, BookItem } from "../models/order.model";
import { UserType } from "../models/user.model";
import { MongoDBConnector } from "../mongodb.connector";
import { BookRepository, BookRepositoryImpl } from "../repositories/book.repository";
import { OrderRepository } from "../repositories/order.repository";
import { BaseServiceImpl } from "./base.service";

export interface OrderService {
    create(newOrderData:NewOrder, userType:string): Promise<Order>
}

@injectable()
export class OrderServiceImpl extends BaseServiceImpl<Order> implements OrderService {
    private dbConnector: MongoDBConnector;
    protected repository: OrderRepository;
    protected bookRepository: BookRepository;
    constructor(
        dbConnector: MongoDBConnector,
        orderRepo: OrderRepository,
    ) {
        super();
        this.dbConnector = dbConnector;
        this.repository = orderRepo;
        this.bookRepository = new BookRepositoryImpl(dbConnector);
    }
    async create(newOrderData:NewOrder): Promise<Order>
    {
       return await this.createWithoutCheck(newOrderData); 
    }
    async createWithoutCheck(newOrderData:NewOrder): Promise<Order> 
    {
        const orderId = randomBytes(20).toString('hex');

        const order: Order = {
            _id: orderId,
            books: newOrderData.books,
            timestamp: newOrderData.timestamp,
            price: newOrderData.price,
            paymentType: newOrderData.paymentType,
            couponId: newOrderData.couponId,
            couponCode: newOrderData.couponCode,
            userInfo: newOrderData.userInfo,
            ...newOrderData
        }

        const [result] = await Promise.all([
            this.repository.insert(order)
        ]);

        for(let i=0;i<order.books.length;i++)
        {
            await this.bookRepository.update({_id: order.books[i].bookId}, { $inc: { sold: order.books[i].amount, amount: -1} } )
        }

        return result;
    }
    protected getKeyFilter(param:string): Filter<Order> 
    {
        return {
            _id: param
        }
    }
    async getAll(params) 
    {
        return await this.repository.find(params);
    }
    async getOne(orderId: string): Promise<Order> 
    {
        let order=await super.getOne(orderId);
        for(let i=0;i<order.books.length;i++)
        {
            order.books[i].book = await this.bookRepository.findOne({_id: order.books[i].bookId});
        }
        console.log(order)
        return order;
    }
    async send(orderId: string, date:string)
    {
        this.repository.update({_id: orderId}, {$set: { sentDate: date}})
    }
}