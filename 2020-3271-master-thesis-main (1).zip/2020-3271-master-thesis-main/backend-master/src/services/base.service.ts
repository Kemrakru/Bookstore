import { injectable } from 'inversify';
import { Filter } from "mongodb";
import { BaseRepository } from '../repositories/base.repository';

export interface BaseService<T> {
    getAll(params:any):Promise<T[]>;
    getOne(id:string):Promise<T>;
    buildPatchChanges<IN extends {}, OUT>(data: IN, exclude: (keyof IN)[]): Partial<OUT | null>
}

@injectable()
export abstract class BaseServiceImpl<T> implements BaseService<T> {
    protected repository: BaseRepository<T>;
    constructor(){}

    async getAll(params:any):Promise<T[]>{
        if (params) 
        {
            let parameters = {};
            if (params.author) 
            {
                parameters['authors'] = params.author;
            }
            if (params.category) 
            {
                parameters['categories'] = params.category;
            }
            if (params.searchTitle) 
            {
                const regex = RegExp(params.search, 'ig');
                parameters['title'] = regex;
            } else if (params.search) 
            {
                const regex = RegExp(params.search, 'ig');
                parameters['$or'] = [ {'title': regex}, {'authors': regex} ]
            }
            
            return this.repository.find(parameters);
        }
       
        return this.repository.find({});
    }
    async getOne(id:string):Promise<T>{
        return await this.repository.findOne({'_id': id});
    }
    protected getFilter(param:string):Filter<T>{
        return;
    }
    buildPatchChanges<IN extends {}, OUT>(data: IN, exclude: (keyof IN)[] = []): Partial<OUT | null> {
        const editableProperties = Object.keys(data)
            .filter(key => exclude.indexOf(<keyof IN>key) === -1);

            console.log(editableProperties)
        if (editableProperties.length > 0) {
            return editableProperties.reduce((payload, key) => {
                const value = data[key];
                payload[key] = value;
                return payload;
            }, {});
        } else {
            //Nothing to be changed
            return null;
        }
    }
}