"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WishlistServiceImpl = void 0;
const crypto_1 = require("crypto");
const inversify_1 = require("inversify");
const error_types_1 = require("../common/error.types");
const user_model_1 = require("../models/user.model");
const base_service_1 = require("./base.service");
let WishlistServiceImpl = class WishlistServiceImpl extends base_service_1.BaseServiceImpl {
    constructor(dbConnector, wishlistRepo) {
        super();
        this.repository = wishlistRepo;
        this.dbConnector = dbConnector;
    }
    async addBook(wishlistId, data, userId, userType) {
        if (userType === user_model_1.UserType.USER) {
            const list = await this.getOne(wishlistId);
            if (list.userId === userId) {
                const [result] = await Promise.all([
                    this.repository.update({ _id: wishlistId }, { $push: { books: data } })
                ]);
                return result;
            }
            else {
                throw (0, error_types_1.ValidationError)(`No access to change wishlist`);
            }
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to change wishlist`);
        }
    }
    async removeBook(wishlistId, bookId, userId, userType) {
        if (userType === user_model_1.UserType.USER) {
            const list = await this.getOne(wishlistId);
            if (list.userId === userId) {
                const [result] = await Promise.all([
                    this.repository.update({ _id: wishlistId }, { $pull: { books: { _id: bookId } } })
                ]);
                return result;
            }
            else {
                throw (0, error_types_1.ValidationError)(`No access to change wishlist`);
            }
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to change wishlist`);
        }
    }
    async create(newWishlistData, userType) {
        if (userType === user_model_1.UserType.USER) {
            return await this.createWithoutCheck(newWishlistData);
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to create wishlist`);
        }
    }
    async delete(wishlistId, userId, userType) {
        if (userType === user_model_1.UserType.USER) {
            const list = await this.getOne(wishlistId);
            if (list.userId === userId) {
                if (list.default === false) {
                    await this.deleteWithoutCheck(wishlistId);
                }
                else {
                    throw (0, error_types_1.ValidationError)(`Cannot remove default wishlist`);
                }
            }
            else {
                throw (0, error_types_1.ValidationError)(`No access to remove wishlist`);
            }
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to remove wishlist`);
        }
    }
    async patch(wishlistId, data, userId, userType) {
        if (userType === user_model_1.UserType.USER) {
            const list = await this.getOne(wishlistId);
            if (list.userId === userId) {
                if (list.default === false) {
                    await this.patchWithoutCheck(wishlistId, data);
                }
                else {
                    throw (0, error_types_1.ValidationError)(`Cannot change default wishlist`);
                }
            }
            else {
                throw (0, error_types_1.ValidationError)(`No access to change wishlist`);
            }
        }
        else {
            throw (0, error_types_1.ValidationError)(`Insufficient access to change wishlist`);
        }
    }
    async patchWithoutCheck(wishlistId, data) {
        const operations = [
            this.patchRootProperties(wishlistId, data)
        ];
        await Promise.all(operations);
    }
    async deleteWithoutCheck(wishlistId) {
        await this.deleteFromDB(wishlistId);
    }
    async createWithoutCheck(newWishlistData) {
        const wishlistId = (0, crypto_1.randomBytes)(20).toString('hex');
        const wishlist = {
            _id: wishlistId,
            name: newWishlistData.name,
            books: newWishlistData.books,
            default: newWishlistData.default,
            userId: newWishlistData.userId,
        };
        const [result] = await Promise.all([
            this.repository.insert(wishlist)
        ]);
        return result;
    }
    patchRootProperties(wishlistId, data, session) {
        const changes = this.buildPatchChanges(data);
        if (!changes) {
            // no changes, nothing to be done here
            return;
        }
        else {
            return this.repository.update({
                _id: wishlistId
            }, {
                $set: Object.assign({}, changes)
            }, { session });
        }
    }
    async deleteFromDB(wishlistId) {
        await Promise.all([
            this.repository.deleteOne({
                _id: wishlistId
            })
        ]);
    }
    getKeyFilter(param) {
        return {
            _id: param
        };
    }
    async getByUserId(userId) {
        const [result] = await Promise.all([
            this.repository.find({ userId: userId })
        ]);
        return result;
    }
};
WishlistServiceImpl = __decorate([
    (0, inversify_1.injectable)()
], WishlistServiceImpl);
exports.WishlistServiceImpl = WishlistServiceImpl;
