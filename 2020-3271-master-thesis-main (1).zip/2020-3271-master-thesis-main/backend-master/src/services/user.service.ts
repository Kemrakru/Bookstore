import { randomBytes } from "crypto";
import { injectable } from "inversify";
import { ClientSession, Filter } from "mongodb";
import { ValidationError } from "../common/error.types";
import { NewUser, PatchUser, User, UserType } from "../models/user.model";
import { MongoDBConnector } from "../mongodb.connector";
import { UserRepository } from "../repositories/user.repository";
import { BaseServiceImpl } from "./base.service";

export interface UserService {
    create(newUserData:NewUser): Promise<User>
    delete(userId: string, userType:string): Promise<void>
    patch(userId:string, data: PatchUser, authenticatedUser:User): Promise<void>
    login(email:string, password:string):Promise<User>
    authenticateUser(userId:string):Promise<User>
}

@injectable()
export class UserServiceImpl extends BaseServiceImpl<User> implements UserService {
    private loggedInUser:User | null = null;
    private dbConnector:MongoDBConnector;
    protected repository:UserRepository;
    constructor(
        dbConnector: MongoDBConnector,
        userRepo: UserRepository,
    ) {
        super();
        this.dbConnector = dbConnector;
        this.repository = userRepo;
    }
    async create(newUserData:NewUser): Promise<User>{
        return await this.createWithoutCheck(newUserData);
    }
    async delete(userId: string, userType:string): Promise<void>{
        if (userType === UserType.USER) {
            await this.deleteWithoutCheck(userId);
        }else{
            throw ValidationError(`Insufficient access to remove user`);
        }
    }
    async patch(userId:string, data: PatchUser, authenticatedUser: User): Promise<void>{
        if (authenticatedUser._id === userId) {
            await this.patchWithoutCheck(userId, data);
        }else{
            throw ValidationError(`Insufficient access to change user`);
        }
    }

    async patchWithoutCheck(userId: string, data: PatchUser): Promise<void> {
        const operations = [
            this.patchRootProperties(
                userId,
                data
            )
        ];

        await Promise.all(operations);
    }
    async deleteWithoutCheck(userId: string): Promise<void> {
        await this.deleteFromDB(userId);
    }
    async createWithoutCheck(newUserData:NewUser): Promise<User> {
        const userId = randomBytes(20).toString('hex');

        const user: User = {
            _id: userId,
            name:newUserData.name,
            email:newUserData.email,
            password:newUserData.password,
            phone:newUserData.phone,
            fullname:newUserData.fullname,
            address:newUserData.address,
            town:newUserData.town,
            zip:newUserData.zip,
            country:newUserData.country,
            type:newUserData.type,
            ...newUserData
        }

        return await this.repository.insert(user);
    }
    async login(email:string, password:string): Promise<User> {
        const [result] = await Promise.all([
            this.repository.findOne({
                email,
                password
            })
        ]);
        this.loggedInUser = result;
        return result;
    }

    async authenticateUser(userId:string):Promise<User>{
        const user = await this.repository.findOne({'_id' : userId});
        if(user){
            return user;
        }else{
            throw ValidationError(`Bad access`);
        }
    }

    private async patchRootProperties(userId: string, data: PatchUser): Promise<void> {
        const changes = this.buildPatchChanges<PatchUser, User>(data);
        if (!changes) {
            // no changes, nothing to be done here
            return;
        } else {
            return await this.repository.update({
                _id: userId
            }, {
                $set: {
                    ...changes
                }
            });
        }
    }
    private async deleteFromDB(userId: string): Promise<void> {
        await this.dbConnector.transaction(async (session: ClientSession): Promise<void> => {
            await Promise.all([
                this.repository.deleteOne({
                    _id: userId
                }, { session })
            ])
        })
    }
    protected getKeyFilter(param:string): Filter<User> {
        return {
            _id: param
        }
    }
}