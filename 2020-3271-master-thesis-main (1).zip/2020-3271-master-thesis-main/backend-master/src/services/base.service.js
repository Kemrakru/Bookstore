"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseServiceImpl = void 0;
const inversify_1 = require("inversify");
let BaseServiceImpl = class BaseServiceImpl {
    constructor() { }
    async getAll(params) {
        if (params) {
            let parameters = {};
            if (params.author) {
                parameters['authors'] = params.author;
            }
            if (params.category) {
                parameters['categories'] = params.category;
            }
            if (params.searchTitle) {
                const regex = RegExp(params.search, 'ig');
                parameters['title'] = regex;
            }
            else if (params.search) {
                const regex = RegExp(params.search, 'ig');
                parameters['$or'] = [{ 'title': regex }, { 'authors': regex }];
            }
            return this.repository.find(parameters);
        }
        return this.repository.find({});
    }
    async getOne(id) {
        return await this.repository.findOne({ '_id': id });
    }
    getFilter(param) {
        return;
    }
    buildPatchChanges(data, exclude = []) {
        const editableProperties = Object.keys(data)
            .filter(key => exclude.indexOf(key) === -1);
        console.log(editableProperties);
        if (editableProperties.length > 0) {
            return editableProperties.reduce((payload, key) => {
                const value = data[key];
                payload[key] = value;
                return payload;
            }, {});
        }
        else {
            //Nothing to be changed
            return null;
        }
    }
};
BaseServiceImpl = __decorate([
    (0, inversify_1.injectable)()
], BaseServiceImpl);
exports.BaseServiceImpl = BaseServiceImpl;
