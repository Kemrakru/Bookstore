import express, { Router } from "express";
import { injectable } from "inversify";
import { UserServiceImpl } from "../services/user.service";
const stripe = require("stripe")(
  "sk_test_51JcC8UJVtxBqJxu3DD41GJjVAbD0A2dMhf69Q6JqkTLZGzE2JH17vdxebefsdHavI2iLZXgWjVd2aZNd7EKnVWuX00Z8KeTriD"
);

@injectable()
export class StripeController {
  protected router = express.Router();
  protected userService: UserServiceImpl;

  constructor() {}

  getController() {
    this.router.route("/").post(async (req, res) => {
      stripe.paymentIntents.create(
        {
          amount: parseInt(req.body.amount) * 100,
          currency: "usd",
          payment_method_types: ["card"],
        },
        function (err, paymentIntent) {
          if (err) {
            res.status(500).json(err.message);
          } else {
            res.status(201).json(paymentIntent);
          }
        }
      );
    });
  }
  getRouter(): Router {
    this.getController();
    return this.router;
  }
}
