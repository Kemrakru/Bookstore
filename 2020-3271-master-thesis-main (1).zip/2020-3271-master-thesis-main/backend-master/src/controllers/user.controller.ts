import { User, NewUser, PatchUser } from '../models/user.model';
import { Wishlist } from '../models/wishlist.model';
import { MongoDBConnectorImpl } from '../mongodb.connector';
import { UserRepositoryImpl } from '../repositories/user.repository';
import { WishlistRepositoryImpl } from '../repositories/wishlist.repository';
import { UserServiceImpl } from '../services/user.service';
import { WishlistServiceImpl } from '../services/wishlist.service';
import { validateId, validateNew } from '../validators';
import { BaseControllerImpl } from './base.controller';

export class UserController extends BaseControllerImpl<User> {
    protected service: UserServiceImpl;
    constructor(conector:MongoDBConnectorImpl){
        super();
        this.service = new UserServiceImpl(conector, new UserRepositoryImpl(conector));
        const wishlistService = new WishlistServiceImpl(conector, new WishlistRepositoryImpl(conector));

        this.router.route('/').post(async (req, res) => {
            let data = req.body.data;
            console.log(data)
            validateNew<NewUser>(data,"user");
            const result = await this.service.create(data);
            const wishlistDefault = {name: 'My Wishlist', books: [], default: true, userId: result._id};
            wishlistService.create(wishlistDefault, 'user');
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{user:result}],
            });
        });

        this.router.route('/login').post(async (req, res) => {
            let data = req.body.data;
            console.log(data)
            const result = await this.service.login(data.email, data.password);
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{user:result}],
            });
        });

        this.router.route('/:id').patch(async (req, res) => {
            let data = req.body.data;
            let id = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.service.authenticateUser(userId);
            console.log(id)
           
            validateNew<PatchUser>(data,"user");
            res.json(await this.service.patch(id, data, authenticatedUser));
        })

        this.router.route('/:id').delete(async (req, res) => {
            let id = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.service.authenticateUser(userId);
            validateId(id);
            res.json(await this.service.delete(id, authenticatedUser.type));
        });
    }
}