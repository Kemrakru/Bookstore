"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderController = void 0;
const order_repository_1 = require("../repositories/order.repository");
const mail_service_1 = require("../services/mail.service");
const order_service_1 = require("../services/order.service");
const base_controller_1 = require("./base.controller");
class OrderController extends base_controller_1.BaseControllerImpl {
    constructor(conector) {
        super();
        this.service = new order_service_1.OrderServiceImpl(conector, new order_repository_1.OrderRepositoryImpl(conector));
        this.mailService = new mail_service_1.MailService();
        this.router.route("/").post(async (req, res) => {
            let data = req.body.data;
            console.log(data);
            const result = await this.service.create(data);
            this.mailService.sendConfirmationEmail(result, result.userInfo.email);
            this.mailService.sendConfirmationEmail(result);
            res.status(200).json({
                status: "success",
                message: `response200`,
                data: [{ order: result }],
            });
        });
        this.router.route("/user").get(async (req, res) => {
            let userId = req.query.userId;
            res.json(await this.service.getAll({ userId: userId }));
        });
        this.router.route("/send").post(async (req, res) => {
            let data = req.body.data;
            console.log(data);
            const result = await this.service.send(data._id, data.sentDate);
            this.mailService.sendOrderSentEmail(data, data.userInfo.email);
            res.status(200).json({
                status: "success",
                message: `response200`,
                data: [{ order: result }],
            });
        });
    }
}
exports.OrderController = OrderController;
