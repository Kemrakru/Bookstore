import { Order, NewOrder } from "../models/order.model";
import { MongoDBConnectorImpl } from "../mongodb.connector";
import { OrderRepositoryImpl } from "../repositories/order.repository";
import { MailService } from "../services/mail.service";
import { OrderServiceImpl } from "../services/order.service";
import { validateNew } from "../validators";
import { BaseControllerImpl } from "./base.controller";

export class OrderController extends BaseControllerImpl<Order> {
  protected service: OrderServiceImpl;
  private mailService: MailService;
  constructor(conector: MongoDBConnectorImpl) {
    super();
    this.service = new OrderServiceImpl(
      conector,
      new OrderRepositoryImpl(conector)
    );
    this.mailService = new MailService();

    this.router.route("/").post(async (req, res) => {
      let data = req.body.data;
      console.log(data);
      const result = await this.service.create(data);
      this.mailService.sendConfirmationEmail(result, result.userInfo.email);
      this.mailService.sendConfirmationEmail(result);
      res.status(200).json({
        status: "success",
        message: `response200`,
        data: [{ order: result }],
      });
    });

    this.router.route("/user").get(async (req, res) => {
      let userId = req.query.userId;
      res.json(await this.service.getAll({ userId: userId }));
    });

    this.router.route("/send").post(async (req, res) => {
      let data = req.body.data;
      console.log(data);
      const result = await this.service.send(data._id, data.sentDate);
      this.mailService.sendOrderSentEmail(data, data.userInfo.email);
      res.status(200).json({
        status: "success",
        message: `response200`,
        data: [{ order: result }],
      });
    });
  }
}
