"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CouponController = void 0;
const coupon_repository_1 = require("../repositories/coupon.repository");
const user_repository_1 = require("../repositories/user.repository");
const coupon_service_1 = require("../services/coupon.service");
const user_service_1 = require("../services/user.service");
const validators_1 = require("../validators");
const base_controller_1 = require("./base.controller");
const fs = require('fs');
class CouponController extends base_controller_1.BaseControllerImpl {
    constructor(conector) {
        super();
        this.service = new coupon_service_1.CouponServiceImpl(conector, new coupon_repository_1.CouponRepositoryImpl(conector));
        this.userService = new user_service_1.UserServiceImpl(conector, new user_repository_1.UserRepositoryImpl(conector));
        this.router.route('/').post(async (req, res) => {
            let data = req.body.data;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            console.log(data);
            (0, validators_1.validateNew)(data, "coupon");
            const result = await this.service.create(data, authenticatedUser.type);
            const img = req.body.banner;
            if (img) {
                var base64Data = img.replace(/^data:image\/png;base64,/, "");
                var base64Data = img.replace(/^data:image\/jpeg;base64,/, "");
                var imgBuffer = Buffer.from(base64Data, 'base64');
                fs.writeFile("../frontend/src/assets/images/couponBanners/" + data.banner, imgBuffer, 'base64', function (err) {
                    console.log(err);
                });
            }
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{ coupon: result }],
            });
        });
        this.router.route('/:id').patch(async (req, res) => {
            let data = req.body.data;
            let id = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            console.log(data);
            (0, validators_1.validateNew)(data, "coupon");
            const img = req.body.banner;
            console.log(id);
            let result = await this.service.patch(id, data, authenticatedUser.type);
            if (img) {
                var base64Data = img.replace(/^data:image\/png;base64,/, "");
                var base64Data = img.replace(/^data:image\/jpeg;base64,/, "");
                var imgBuffer = Buffer.from(base64Data, 'base64');
                fs.writeFile("../frontend/src/assets/images/couponBanners/" + data.banner, imgBuffer, 'base64', function (err) {
                    console.log(err);
                });
            }
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{ coupon: result }],
            });
        });
        this.router.route('/').delete(async (req, res) => {
            let id = req.query.couponId;
            const userId = req.query.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            res.json(await this.service.delete(id, authenticatedUser.type));
        });
        this.router.route('/active').get(async (req, res) => {
            res.json(await this.service.getActive());
        });
    }
}
exports.CouponController = CouponController;
