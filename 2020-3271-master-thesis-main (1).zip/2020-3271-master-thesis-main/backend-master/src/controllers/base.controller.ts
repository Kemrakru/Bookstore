import express, { Router } from 'express';
import { injectable } from 'inversify';
import { BaseService } from '../services/base.service';
import { UserServiceImpl } from '../services/user.service';

export interface BaseController<T> {
    getController():void;
}

@injectable()
export abstract class BaseControllerImpl<T> implements BaseController<T> 
{
    protected router = express.Router();
    protected service: BaseService<T>;
    protected userService: UserServiceImpl;
    
    constructor(){}

    getController() {
        this.router.route('/').get(async (req, res) => 
        {
            console.log(req.query)
            res.json(await this.service.getAll(req.query));
        });

        this.router.route('/:id').get(async (req, res) => 
        {
            let id = req.params.id
            res.json(await this.service.getOne(id));
        });
    }

    getRouter(): Router 
    {
        this.getController();
        return this.router;
    }
}