"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const user_repository_1 = require("../repositories/user.repository");
const wishlist_repository_1 = require("../repositories/wishlist.repository");
const user_service_1 = require("../services/user.service");
const wishlist_service_1 = require("../services/wishlist.service");
const validators_1 = require("../validators");
const base_controller_1 = require("./base.controller");
class UserController extends base_controller_1.BaseControllerImpl {
    constructor(conector) {
        super();
        this.service = new user_service_1.UserServiceImpl(conector, new user_repository_1.UserRepositoryImpl(conector));
        const wishlistService = new wishlist_service_1.WishlistServiceImpl(conector, new wishlist_repository_1.WishlistRepositoryImpl(conector));
        this.router.route('/').post(async (req, res) => {
            let data = req.body.data;
            console.log(data);
            (0, validators_1.validateNew)(data, "user");
            const result = await this.service.create(data);
            const wishlistDefault = { name: 'My Wishlist', books: [], default: true, userId: result._id };
            wishlistService.create(wishlistDefault, 'user');
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{ user: result }],
            });
        });
        this.router.route('/login').post(async (req, res) => {
            let data = req.body.data;
            console.log(data);
            const result = await this.service.login(data.email, data.password);
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{ user: result }],
            });
        });
        this.router.route('/:id').patch(async (req, res) => {
            let data = req.body.data;
            let id = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.service.authenticateUser(userId);
            console.log(id);
            (0, validators_1.validateNew)(data, "user");
            res.json(await this.service.patch(id, data, authenticatedUser));
        });
        this.router.route('/:id').delete(async (req, res) => {
            let id = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.service.authenticateUser(userId);
            (0, validators_1.validateId)(id);
            res.json(await this.service.delete(id, authenticatedUser.type));
        });
    }
}
exports.UserController = UserController;
