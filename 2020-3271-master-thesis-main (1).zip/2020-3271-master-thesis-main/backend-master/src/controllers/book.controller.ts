import { ChatbotService } from "../chatbot/chatbot.service";
import { Book, NewBook, PatchBook } from "../models/book.model";
import { MongoDBConnectorImpl } from "../mongodb.connector";
import { BookRepositoryImpl } from "../repositories/book.repository";
import { UserRepositoryImpl } from "../repositories/user.repository";
import { BookServiceImpl } from "../services/book.service";
import { UserServiceImpl } from "../services/user.service";
import { validateId, validateNew, validatePatch } from "../validators";
import { BaseControllerImpl } from "./base.controller";

const fs = require("fs");

export class BookController extends BaseControllerImpl<Book> {
  protected service: BookServiceImpl;
  protected userService: UserServiceImpl;
  protected chatbotService: ChatbotService;
  constructor(conector: MongoDBConnectorImpl, chatbotService: ChatbotService) {
    super();
    this.service = new BookServiceImpl(
      conector,
      new BookRepositoryImpl(conector)
    );
    this.userService = new UserServiceImpl(
      conector,
      new UserRepositoryImpl(conector)
    );
    this.chatbotService = chatbotService;
    this.router.route("/").post(async (req, res) => {
      let data = req.body.data;
      const userId = req.body.userId;
      const img = req.body.coverImage;
      const authenticatedUser = await this.userService.authenticateUser(userId);

      validateNew<NewBook>(data, "book");

      const result = await this.service.create(data, authenticatedUser.type);

      if (img) {
        var base64Data = img.replace(/^data:image\/png;base64,/, "");
        var base64Data = img.replace(/^data:image\/jpeg;base64,/, "");
        var imgBuffer = Buffer.from(base64Data, "base64");
        fs.writeFile(
          "../frontend/src/assets/images/bookCovers/" + data.cover,
          imgBuffer,
          "base64",
          function (err) {
            console.log(err);
          }
        );
      }

      let rawdata = fs.readFileSync("./src/chatbot/corpora/books-en.json");
      let books = JSON.parse(rawdata);
      console.log(books);
      books.data.push({
        intent: "book." + data.title + " " + result._id,
        utterances: data.description
          .split(".")
          .concat(data.categories)
          .concat([data.authors[0]])
          .filter((b) => b),
        answers: [data.title],
      });

      let jsonData = JSON.stringify(books);
      fs.writeFileSync("./src/chatbot/corpora/books-en.json", jsonData);

      this.chatbotService.runTrain("src/chatbot/corpora/books-en.json");

      res.status(200).json({
        status: "success",
        message: `response200`,
        data: [{ book: result }],
      });
    });

    this.router.route("/:id").patch(async (req, res) => {
      let data = req.body.data;
      let id = req.params.id;
      const userId = req.body.userId;
      const authenticatedUser = await this.userService.authenticateUser(userId);
      console.log(id);
      console.log(data);

      const img = req.body.coverImage;
      if (img) {
        var base64Data = img.replace(/^data:image\/png;base64,/, "");
        var base64Data = img.replace(/^data:image\/jpeg;base64,/, "");
        var imgBuffer = Buffer.from(base64Data, "base64");
        fs.writeFile(
          "../frontend/src/assets/images/bookCovers/" + data.cover,
          imgBuffer,
          "base64",
          function (err) {
            console.log(err);
          }
        );
      }

      res.json(await this.service.patch(id, data, authenticatedUser.type));
    });

    this.router.route("/:id").delete(async (req, res) => {
      let id = req.params.id;
      const userId = req.body.userId;
      const authenticatedUser = await this.userService.authenticateUser(userId);
      validateId(id);
      res.json(await this.service.delete(id, authenticatedUser.type));
    });

    this.router.route("/best-selling").get(async (req, res) => {
      res.json(await this.service.getBestSellingBooks());
    });
  }
}
