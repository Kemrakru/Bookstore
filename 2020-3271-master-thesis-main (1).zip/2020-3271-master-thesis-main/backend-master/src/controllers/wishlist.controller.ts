import { Wishlist, NewWishlist, PatchWishlist } from '../models/wishlist.model';
import { MongoDBConnectorImpl } from '../mongodb.connector';
import { UserRepositoryImpl } from '../repositories/user.repository';
import { WishlistRepositoryImpl } from '../repositories/wishlist.repository';
import { UserServiceImpl } from '../services/user.service';
import { WishlistServiceImpl } from '../services/wishlist.service';
import { validateId, validateNew, validatePatch } from '../validators';
import { BaseControllerImpl } from './base.controller';


export class WishlistController extends BaseControllerImpl<Wishlist> {
    protected service: WishlistServiceImpl;
    protected userService: UserServiceImpl;

    constructor(conector:MongoDBConnectorImpl){
        super();
        this.service = new WishlistServiceImpl(conector, new WishlistRepositoryImpl(conector));
        this.userService = new UserServiceImpl(conector, new UserRepositoryImpl(conector));

        this.router.route('/').post(async (req, res) => {
            let data = req.body.data;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            validateNew<NewWishlist>(data,"wishlist");
            const result = await this.service.create(data, authenticatedUser.type);
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{Wishlist:result}],
            });
        });

        this.router.route('/add/:id').patch(async (req, res) => {
            const data = req.body.data;
            const wishlistId = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            const result = await this.service.addBook(wishlistId,data,authenticatedUser._id, authenticatedUser.type);
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{Wishlist:result}],
            });
        });

        this.router.route('/remove/:id').patch(async (req, res) => {
            const bookId = req.body.bookId;
            const wishlistId = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            const result = await this.service.removeBook(wishlistId,bookId,authenticatedUser._id, authenticatedUser.type);
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{Wishlist:result}],
            });
        });

        this.router.route('/:id').patch(async (req, res) => {
            let data = req.body.data;
            let id = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            validateId(id);
            validateNew<PatchWishlist>(data,"wishlist");
            res.json(await this.service.patch(id, data, authenticatedUser._id, authenticatedUser.type));
        })

        this.router.route('/').delete(async (req, res) => {
            let id = req.query.wishlistId as string;
            const userId = req.query.userId as string;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            res.json(await this.service.delete(id, authenticatedUser._id, authenticatedUser.type));
        });

        this.router.route('/:id').get(async (req, res) => {
            const userId = req.params.id;
            const result = await this.service.getByUserId(userId);
            res.status(200).json(result);
        });
    }
}