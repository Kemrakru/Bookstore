"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StripeController = void 0;
const express_1 = __importDefault(require("express"));
const inversify_1 = require("inversify");
const stripe = require("stripe")("sk_test_51JcC8UJVtxBqJxu3DD41GJjVAbD0A2dMhf69Q6JqkTLZGzE2JH17vdxebefsdHavI2iLZXgWjVd2aZNd7EKnVWuX00Z8KeTriD");
let StripeController = class StripeController {
    constructor() {
        this.router = express_1.default.Router();
    }
    getController() {
        this.router.route("/").post(async (req, res) => {
            stripe.paymentIntents.create({
                amount: parseInt(req.body.amount) * 100,
                currency: "usd",
                payment_method_types: ["card"],
            }, function (err, paymentIntent) {
                if (err) {
                    res.status(500).json(err.message);
                }
                else {
                    res.status(201).json(paymentIntent);
                }
            });
        });
    }
    getRouter() {
        this.getController();
        return this.router;
    }
};
StripeController = __decorate([
    (0, inversify_1.injectable)()
], StripeController);
exports.StripeController = StripeController;
