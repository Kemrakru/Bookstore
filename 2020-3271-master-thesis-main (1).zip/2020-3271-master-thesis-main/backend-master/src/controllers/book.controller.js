"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookController = void 0;
const book_repository_1 = require("../repositories/book.repository");
const user_repository_1 = require("../repositories/user.repository");
const book_service_1 = require("../services/book.service");
const user_service_1 = require("../services/user.service");
const validators_1 = require("../validators");
const base_controller_1 = require("./base.controller");
const fs = require("fs");
class BookController extends base_controller_1.BaseControllerImpl {
    constructor(conector, chatbotService) {
        super();
        this.service = new book_service_1.BookServiceImpl(conector, new book_repository_1.BookRepositoryImpl(conector));
        this.userService = new user_service_1.UserServiceImpl(conector, new user_repository_1.UserRepositoryImpl(conector));
        this.chatbotService = chatbotService;
        this.router.route("/").post(async (req, res) => {
            let data = req.body.data;
            const userId = req.body.userId;
            const img = req.body.coverImage;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            (0, validators_1.validateNew)(data, "book");
            const result = await this.service.create(data, authenticatedUser.type);
            if (img) {
                var base64Data = img.replace(/^data:image\/png;base64,/, "");
                var base64Data = img.replace(/^data:image\/jpeg;base64,/, "");
                var imgBuffer = Buffer.from(base64Data, "base64");
                fs.writeFile("../frontend/src/assets/images/bookCovers/" + data.cover, imgBuffer, "base64", function (err) {
                    console.log(err);
                });
            }
            let rawdata = fs.readFileSync("./src/chatbot/corpora/books-en.json");
            let books = JSON.parse(rawdata);
            console.log(books);
            books.data.push({
                intent: "book." + data.title + " " + result._id,
                utterances: data.description
                    .split(".")
                    .concat(data.categories)
                    .concat([data.authors[0]])
                    .filter((b) => b),
                answers: [data.title],
            });
            let jsonData = JSON.stringify(books);
            fs.writeFileSync("./src/chatbot/corpora/books-en.json", jsonData);
            this.chatbotService.runTrain("src/chatbot/corpora/books-en.json");
            res.status(200).json({
                status: "success",
                message: `response200`,
                data: [{ book: result }],
            });
        });
        this.router.route("/:id").patch(async (req, res) => {
            let data = req.body.data;
            let id = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            console.log(id);
            console.log(data);
            const img = req.body.coverImage;
            if (img) {
                var base64Data = img.replace(/^data:image\/png;base64,/, "");
                var base64Data = img.replace(/^data:image\/jpeg;base64,/, "");
                var imgBuffer = Buffer.from(base64Data, "base64");
                fs.writeFile("../frontend/src/assets/images/bookCovers/" + data.cover, imgBuffer, "base64", function (err) {
                    console.log(err);
                });
            }
            res.json(await this.service.patch(id, data, authenticatedUser.type));
        });
        this.router.route("/:id").delete(async (req, res) => {
            let id = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            (0, validators_1.validateId)(id);
            res.json(await this.service.delete(id, authenticatedUser.type));
        });
        this.router.route("/best-selling").get(async (req, res) => {
            res.json(await this.service.getBestSellingBooks());
        });
    }
}
exports.BookController = BookController;
