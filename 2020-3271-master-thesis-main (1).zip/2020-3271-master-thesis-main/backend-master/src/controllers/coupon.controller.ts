import { Coupon, NewCoupon, PatchCoupon } from '../models/coupon.model';
import { MongoDBConnectorImpl } from '../mongodb.connector';
import { CouponRepositoryImpl } from '../repositories/coupon.repository';
import { UserRepositoryImpl } from '../repositories/user.repository';
import { CouponServiceImpl } from '../services/coupon.service';
import { UserServiceImpl } from '../services/user.service';
import { validateId, validateNew } from '../validators';
import { BaseControllerImpl } from './base.controller';

const fs = require('fs');

export class CouponController extends BaseControllerImpl<Coupon> {
    protected service: CouponServiceImpl;
    protected userService: UserServiceImpl;
    constructor(conector:MongoDBConnectorImpl){
        super();
        this.service = new CouponServiceImpl(conector, new CouponRepositoryImpl(conector));
        this.userService = new UserServiceImpl(conector, new UserRepositoryImpl(conector));

        this.router.route('/').post(async (req, res) => {
            let data = req.body.data;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            console.log(data)
            validateNew<NewCoupon>(data,"coupon");
            const result = await this.service.create(data, authenticatedUser.type);
            const img = req.body.banner;
            if (img) 
            {
                var base64Data = img.replace(/^data:image\/png;base64,/, "");
                var base64Data = img.replace(/^data:image\/jpeg;base64,/, "");
                var imgBuffer = Buffer.from(base64Data, 'base64');
                fs.writeFile("../frontend/src/assets/images/couponBanners/"+data.banner, imgBuffer, 'base64', function(err) {
                    console.log(err);
                });
            }
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{coupon:result}],
            });
        });

        this.router.route('/:id').patch(async (req, res) => {
            let data = req.body.data;
            let id = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            console.log(data)
            validateNew<PatchCoupon>(data,"coupon");
            const img = req.body.banner;
            console.log(id)
            let result = await this.service.patch(id, data, authenticatedUser.type);
           
            if (img) 
            {
                var base64Data = img.replace(/^data:image\/png;base64,/, "");
                var base64Data = img.replace(/^data:image\/jpeg;base64,/, "");
                var imgBuffer = Buffer.from(base64Data, 'base64');
                fs.writeFile("../frontend/src/assets/images/couponBanners/"+data.banner, imgBuffer, 'base64', function(err) {
                    console.log(err);
                });
            }
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{coupon:result}],
            });
        })

        this.router.route('/').delete(async (req, res) => {
            let id = req.query.couponId as string;
            const userId = req.query.userId as string;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            res.json(await this.service.delete(id, authenticatedUser.type));
        });

        this.router.route('/active').get(async (req, res) => {
            res.json(await this.service.getActive());
        });
    }
}