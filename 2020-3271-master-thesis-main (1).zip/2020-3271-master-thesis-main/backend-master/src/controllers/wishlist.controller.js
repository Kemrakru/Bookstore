"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WishlistController = void 0;
const user_repository_1 = require("../repositories/user.repository");
const wishlist_repository_1 = require("../repositories/wishlist.repository");
const user_service_1 = require("../services/user.service");
const wishlist_service_1 = require("../services/wishlist.service");
const validators_1 = require("../validators");
const base_controller_1 = require("./base.controller");
class WishlistController extends base_controller_1.BaseControllerImpl {
    constructor(conector) {
        super();
        this.service = new wishlist_service_1.WishlistServiceImpl(conector, new wishlist_repository_1.WishlistRepositoryImpl(conector));
        this.userService = new user_service_1.UserServiceImpl(conector, new user_repository_1.UserRepositoryImpl(conector));
        this.router.route('/').post(async (req, res) => {
            let data = req.body.data;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            (0, validators_1.validateNew)(data, "wishlist");
            const result = await this.service.create(data, authenticatedUser.type);
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{ Wishlist: result }],
            });
        });
        this.router.route('/add/:id').patch(async (req, res) => {
            const data = req.body.data;
            const wishlistId = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            const result = await this.service.addBook(wishlistId, data, authenticatedUser._id, authenticatedUser.type);
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{ Wishlist: result }],
            });
        });
        this.router.route('/remove/:id').patch(async (req, res) => {
            const bookId = req.body.bookId;
            const wishlistId = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            const result = await this.service.removeBook(wishlistId, bookId, authenticatedUser._id, authenticatedUser.type);
            res.status(200).json({
                status: 'success',
                message: `response200`,
                data: [{ Wishlist: result }],
            });
        });
        this.router.route('/:id').patch(async (req, res) => {
            let data = req.body.data;
            let id = req.params.id;
            const userId = req.body.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            (0, validators_1.validateId)(id);
            (0, validators_1.validateNew)(data, "wishlist");
            res.json(await this.service.patch(id, data, authenticatedUser._id, authenticatedUser.type));
        });
        this.router.route('/').delete(async (req, res) => {
            let id = req.query.wishlistId;
            const userId = req.query.userId;
            const authenticatedUser = await this.userService.authenticateUser(userId);
            res.json(await this.service.delete(id, authenticatedUser._id, authenticatedUser.type));
        });
        this.router.route('/:id').get(async (req, res) => {
            const userId = req.params.id;
            const result = await this.service.getByUserId(userId);
            res.status(200).json(result);
        });
    }
}
exports.WishlistController = WishlistController;
