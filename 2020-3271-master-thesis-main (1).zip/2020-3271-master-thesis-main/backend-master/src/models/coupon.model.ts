import { Element } from "./base.model";

export interface Coupon extends Element{
    categories: string;
    dateTo: string;
    name: string;
    code: string;
    amount: number;
    banner: string;
    discount: number;
}

export interface NewCoupon{
    categories: string;
    dateTo: string;
    name: string;
    code: string;
    amount: number;
    banner: string;
    discount: number;
}

export interface PatchCoupon{
    categories?: string;
    dateTo?: string;
    name?: string;
    code?: string;
    amount?: number;
    banner: string;
    discount: number;
}