import { Element } from "./base.model";

export interface User extends Element {
    name: string;
    email: string;
    password: string;
    phone: string;
    fullname: string;
    address: string;
    town: string;
    state?: string;
    zip: string;
    country: string;
    type: string;
}

export interface NewUser {
    name: string;
    email: string;
    password: string;
    phone: string;
    fullname: string;
    address: string;
    town: string;
    state?: string;
    zip: string;
    country: string;
    type: string;
}

export interface PatchUser{
    name?: string;
    email?: string;
    password?: string;
    phone?: string;
    fullname?: string;
    address?: string;
    town?: string;
    state?: string;
    zip?: string;
    country?: string;
    type?: string;
}

export enum UserType {
    ADMIN = "admin",
    USER = "user"
}