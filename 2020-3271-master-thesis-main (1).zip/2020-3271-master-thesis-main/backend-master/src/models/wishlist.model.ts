import { Element } from "./base.model";
import { SimpleBook } from "./book.model";

export interface Wishlist extends Element {
    name: string;
    books: SimpleBook[];
    default: boolean;
    userId: string;
}

export interface NewWishlist {
    name: string;
    books: SimpleBook[];
    default: boolean;
    userId: string;
}

export interface PatchWishlist {
    name?: string;
    books?: SimpleBook[];
    default?: boolean;
    userId?: string;
}