import { Element } from "./base.model";

export interface Book extends Element {
    isbn: string;
    title: string;
    available: boolean;
    amount: number;
    sold:number;
    cover: string;
    authors: string[];
    categories: string[];
    coverType: string;
    pages: number;
    pubDate: string;
    publisher: string;
    description: string;
    language: string;
    price: number;  
    rating: string;
    ratingsNum: string;
}

export interface NewBook{
    isbn: string;
    title: string;
    available: boolean;
    amount: number;
    sold:number;
    cover: string;
    authors: string[];
    categories: string[];
    coverType: string;
    pages: number;
    pubDate: string;
    publisher: string;
    description: string;
    language: string;
    price: number;
    rating: string;
    ratingsNum: string;
}

export interface PatchBook{
    isbn?: string;
    title?: string;
    available?: boolean;
    amount?: number;
    sold?:number;
    category?: string[];
    cover?: string;
    authors?: string[];
    categories?: string[];
    coverType?: string;
    pages?: number;
    pubDate?: string;
    publisher?: string;
    description?: string;
    language?: string;
    price?: number;
    rating?: string;
    ratingsNum?: string;
}

export interface Category{
    name: string;
}

export interface SimpleBook{
    _id: string;
    title: string;
    available: boolean;
    amount: number;
    cover: string;
    authors: string[];
    price: number; 
}