import { Element } from "./base.model";
import { Book } from "./book.model";

export interface Order extends Element{
    books: BookItem[];
    timestamp: string;
    userId?: string;
    price: number;
    paymentType: string;
    couponId: string;
    couponCode:string;
    userInfo:any;
    sentDate: string;
}

export interface NewOrder{
    books: BookItem[];
    timestamp: string;
    userId?: string;
    price: number;
    paymentType: string;
    couponId: string;
    couponCode:string;
    userInfo:any;
    sentDate: string;
}

export interface BookItem{
    bookId:string;
    amount:number;
    book:Book;
}