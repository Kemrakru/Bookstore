export interface Element{
    _id: string;
}