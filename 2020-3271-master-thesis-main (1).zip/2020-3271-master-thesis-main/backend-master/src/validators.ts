import Ajv, { JTDDataType, ValidateFunction } from "ajv/dist/jtd";
import { ValidationError } from "./common/error.types";
const ajv = new Ajv();
export function getBookValidatorNew():ValidateFunction{
    const NewBookSchema = {
        properties: {
            isbn: {type:"string"},
            title: {type:"string"},
            available: {type:"boolean"},
            amount: {type:"int32"},
            sold: {type:"int32"},
            cover: {type:"string"},
            authors:{
                elements: {
                    type: "string"
                }
            },
            categories:{
                elements: {
                    type: "string"
                }
            },
            coverType: {type:"string"},
            pages: {type:"int32"},
            pubDate: {type:"string"},
            publisher: {type:"string"},
            description: {type:"string"},
            language: {type:"string"},
            price: {type:"int32"},
            rating: {type:"string"},
            ratingsNum: {type:"string"},
        }
    } as const
    type BookJTD = JTDDataType<typeof NewBookSchema>;
    const validateNewBookSchema = ajv.compile<BookJTD>(NewBookSchema);
    return validateNewBookSchema;
}
export function getBookValidatorPatch():ValidateFunction{
    const PatchBookSchema = {
        optionalProperties: {
            isbn: {type:"string"},
            title: {type:"string"},
            available: {type:"boolean"},
            amount: {type:"int32"},
            sold: {type:"int32"},
            cover: {type:"string"},
            authors:{
                elements: {
                    type: "string"
                }
            },
            categories:{
                elements: {
                    type: "string"
                }
            },
            coverType: {type:"string"},
            pages: {type:"int32"},
            pubDate: {type:"string"},
            publisher: {type:"string"},
            description: {type:"string"},
            language: {type:"string"},
            price: {type:"number"},
            rating: {type:"string"},
            ratingsNum: {type:"string"},
        }
    } as const
    type PatchBookJTD = JTDDataType<typeof PatchBookSchema>;
    const validatePatchBookSchema = ajv.compile<PatchBookJTD>(PatchBookSchema);
    return validatePatchBookSchema;
}

export function getCouponValidatorNew():ValidateFunction{
    const NewCouponSchema = {
        properties: {
            categories:{
                elements: {
                    type: "string"
                }
            },
            dateTo: {type:"string"},
            name: {type:"string"},
            code: {type:"string"},
            amount: {type:"int32"},
            banner: {type:"string"},
            discount: {type:"int32"}
        }
    } as const
    type CouponJTD = JTDDataType<typeof NewCouponSchema>;
    const validateNewCouponSchema = ajv.compile<CouponJTD>(NewCouponSchema);
    return validateNewCouponSchema;
}
export function getCouponValidatorPatch():ValidateFunction{
    const PatchCouponSchema = {
        optionalProperties: {
            categories:{
                elements: {
                    type: "string"
                }
            },
            dateTo: {type:"string"},
            name: {type:"string"},
            code: {type:"string"},
            amount: {type:"int32"},
            banner: {type:"string"},
            discount: {type:"int32"}
        }
    } as const
    type PatchCouponJTD = JTDDataType<typeof PatchCouponSchema>;
    const validatePatchCouponSchema = ajv.compile<PatchCouponJTD>(PatchCouponSchema);
    return validatePatchCouponSchema;
}

export function getOrderValidatorNew():ValidateFunction{
    const NewOrderSchema = {
        properties: {
            books:{
                elements: {
                    properties: {
                        bookId: {type: "string"},
                        amount: {type:"int32"},
                    }
                }
            },
            timestamp: {type:"string"},
            price: {type:"int32"},
            paymentType: {type:"string"},
            couponId: {type:"string"},
            couponCode:{type:"string"},
            userInfo: {
                properties: {
                    email: {type: "string"},
                    fullname: {type:"string"},
                    address: {type: "string"},
                    town: {type:"string"},
                    state: {type: "string"},
                    zip: {type:"string"},
                    phone: {type: "string"},
                    country: {type:"string"}
                }
            },
            sentDate: {type:"string"}
        },
        optionalProperties: {
            userId: {type:"string"}
        }
    } as const
    type OrderJTD = JTDDataType<typeof NewOrderSchema>;
    const validateNewOrderSchema = ajv.compile<OrderJTD>(NewOrderSchema);
    return validateNewOrderSchema;
}

export function getWishlistValidatorNew():ValidateFunction{
    const NewWishlistSchema = {
        properties: {
            name: {type:"string"},
            books:{
                elements:{
                    properties:{
                        title: {type:"string"},
                        available: {type:"boolean"},
                        amount: {type:"int32"},
                        cover: {type:"string"},
                        authors: {
                            elements: {
                                type: "string"
                            }
                        },
                        price: {type:"int32"} 
                    }
                }
            },
            default: {type:"boolean"},
            userId: {type:"string"},
        }
    } as const
    type WishlistJTD = JTDDataType<typeof NewWishlistSchema>;
    const validateNewWishlistSchema = ajv.compile<WishlistJTD>(NewWishlistSchema);
    return validateNewWishlistSchema;
}
export function getWishlistValidatorPatch():ValidateFunction{
    const PatchWishlistSchema = {
        optionalProperties: {
            name: {type:"string"},
            books:{
                elements:{
                    properties:{
                        title: {type:"string"},
                        available: {type:"boolean"},
                        amount: {type:"int32"},
                        cover: {type:"string"},
                        authors: {
                            elements: {
                                type: "string"
                            }
                        },
                        price: {type:"int32"} 
                    }
                }
            },
            default: {type:"boolean"},
            userId: {type:"string"},
        }
    } as const
    type PatchWishlistJTD = JTDDataType<typeof PatchWishlistSchema>;
    const validatePatchWishlistSchema = ajv.compile<PatchWishlistJTD>(PatchWishlistSchema);
    return validatePatchWishlistSchema;
}

export function getUserValidatorNew():ValidateFunction{
    const NewUserSchema = {
        properties: {
            name: {type:"string"},
            email: {type:"string"},
            password: {type:"string"},
            phone: {type:"string"},
            fullname: {type:"string"},
            address: {type:"string"},
            town: {type:"string"},
            zip: {type:"string"},
            country: {type:"string"},
            type: {type:"string"}
        },
        optionalProperties: {
            state: {type:"string"}
        }
    } as const
    type UserJTD = JTDDataType<typeof NewUserSchema>;
    const validateNewUserSchema = ajv.compile<UserJTD>(NewUserSchema);
    return validateNewUserSchema;
}
export function getUserValidatorPatch():ValidateFunction{
    const PatchUserSchema = {
        optionalProperties: {
            name: {type:"string"},
            email: {type:"string"},
            password: {type:"string"},
            phone: {type:"string"},
            fullname: {type:"string"},
            address: {type:"string"},
            town: {type:"string"},
            zip: {type:"string"},
            country: {type:"string"},
            type: {type:"string"},
            state: {type:"string"}
        }
    } as const
    type PatchUserJTD = JTDDataType<typeof PatchUserSchema>;
    const validatePatchUserSchema = ajv.compile<PatchUserJTD>(PatchUserSchema);
    return validatePatchUserSchema;
}

export function getValidatorId():ValidateFunction{
    const idSchema = {
        properties: {
            id: {type:"string"}
        }
    } as const
    type idJTD = JTDDataType<typeof idSchema>;
    const validateIdSchema = ajv.compile<idJTD>(idSchema);
    return validateIdSchema;
}

export function validateId(data: string):void{
    const isValid = getValidatorId()(data);
    validate(isValid);
}

export function validatePatch<T>(data: T, type:string):void{
    let isValid:boolean = false;
    switch (type) {
        case "book":
            isValid = getBookValidatorPatch()(data);
            break;
        case "coupon":
            isValid = getCouponValidatorPatch()(data);
            break;
        case "user":
            isValid = getUserValidatorPatch()(data);
            break;
        case "wishlist":
            isValid = getWishlistValidatorPatch()(data);
            break;
        default:
            break;
    }
    validate(isValid);
}
export function validateNew<T>(data: T, type:string):void{
    let isValid:boolean = false;
    switch (type) {
        case "book":
            isValid = getBookValidatorNew()(data);
            break;
        case "coupon":
            isValid = getCouponValidatorNew()(data);
            break;
        case "order":
            isValid = getOrderValidatorNew()(data);
            break;
        case "user":
            isValid = getUserValidatorNew()(data);
            break;
        case "wishlist":
            isValid = getWishlistValidatorNew()(data);
            break;
        default:
            break;
    }
    validate(isValid);
}

function validate(isValid: boolean):void{
    if (!isValid) {
        const error = getValidatorId().errors[0];
        throw ValidationError(`Property ${error.instancePath} ${error.message}`)
    }
}

