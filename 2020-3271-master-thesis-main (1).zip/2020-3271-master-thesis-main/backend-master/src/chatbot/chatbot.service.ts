const { dockStart } = require("@nlpjs/basic");
const path = require("path");
import crypto from "crypto";
import { injectable } from "inversify";

@injectable()
export class ChatbotService {
  private static dock: any;
  private static nlp: any;
  constructor() {
    this.createAgent().then(() => {
      this.runTrain("./src/chatbot/corpora/corpus-en.json");
      this.runTrain("./src/chatbot/corpora/books-en.json");
    });
  }
  async createAgent() {
    ChatbotService.dock = await dockStart({ use: ["Basic"] });
    ChatbotService.nlp = ChatbotService.dock.get("nlp");
  }
  async runTrain(relativePath: string) {
    try {
      await ChatbotService.nlp.addLanguage("en");
      const fullPath = path.resolve(relativePath);
      await ChatbotService.nlp.addCorpus(fullPath);
      await ChatbotService.nlp.train();
      console.log("Successfully trained nlp");
    } catch (err) {
      console.error(err.message);
    }
  }

  async run(language: string, message: string) {
    try {
      const response = await ChatbotService.nlp.process(language, message);
      return response;
    } catch (err) {
      console.error(err.message);
    }
  }

  generateId(): string {
    const buffer = crypto.randomBytes(20);
    const tokenId = buffer.toString("hex");
    return tokenId;
  }
}
