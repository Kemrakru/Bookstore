"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var ChatbotService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatbotService = void 0;
const { dockStart } = require("@nlpjs/basic");
const path = require("path");
const crypto_1 = __importDefault(require("crypto"));
const inversify_1 = require("inversify");
let ChatbotService = ChatbotService_1 = class ChatbotService {
    constructor() {
        this.createAgent().then(() => {
            this.runTrain("./src/chatbot/corpora/corpus-en.json");
            this.runTrain("./src/chatbot/corpora/books-en.json");
        });
    }
    async createAgent() {
        ChatbotService_1.dock = await dockStart({ use: ["Basic"] });
        ChatbotService_1.nlp = ChatbotService_1.dock.get("nlp");
    }
    async runTrain(relativePath) {
        try {
            await ChatbotService_1.nlp.addLanguage("en");
            const fullPath = path.resolve(relativePath);
            await ChatbotService_1.nlp.addCorpus(fullPath);
            await ChatbotService_1.nlp.train();
            console.log("Successfully trained nlp");
        }
        catch (err) {
            console.error(err.message);
        }
    }
    async run(language, message) {
        try {
            const response = await ChatbotService_1.nlp.process(language, message);
            return response;
        }
        catch (err) {
            console.error(err.message);
        }
    }
    generateId() {
        const buffer = crypto_1.default.randomBytes(20);
        const tokenId = buffer.toString("hex");
        return tokenId;
    }
};
ChatbotService = ChatbotService_1 = __decorate([
    (0, inversify_1.injectable)()
], ChatbotService);
exports.ChatbotService = ChatbotService;
