import express, { Router } from "express";
import { injectable } from "inversify";
import { ChatbotService } from "./chatbot.service";

@injectable()
export class ChatbotController {
  protected router = express.Router();
  protected chatbotService: ChatbotService;
  constructor(chatbotService: ChatbotService) {
    this.chatbotService = chatbotService;
  }

  getRoute() {
    this.router.route("/").post(async (req, res) => {
      console.log(req.body);
      const botResponse = await this.chatbotService.run("en", req.body.message);
      console.log(botResponse);
      if (botResponse) {
        const answerArray = botResponse.classifications
          .filter((a) => a.score > 0)
          .map((b) => b.intent);
        var responseArray: string[] = [];
        const customMessagesArray: string[] = [
          "It was hard but i managed to find this for you:",
          "Hey i found this:",
          "Were you looking for this:",
          "Is this what you were looking for:",
        ];
        if (answerArray[0].includes("book")) {
          responseArray.push(
            customMessagesArray[
              Math.floor(Math.random() * customMessagesArray.length)
            ]
          );
        }
        for (let index = 0; index < answerArray.length; index++) {
          if (answerArray[index].includes("book")) {
            let title = answerArray[index].substring(
              5,
              answerArray[index].length - 41
            );
            let id = answerArray[index].substring(
              answerArray[index].length - 40
            );
            let url = "http://localhost:4200/book/" + id;
            responseArray.push("<a href='" + url + "' >" + title + "</a>");
          }
        }
        console.log(responseArray);
        var resultMessage: string =
          "Sorry, I don't understand. Can you please rephrase your query?";
        var resultIntent: string = "hello";
        if (botResponse.classifications.length > 0) {
          resultMessage = botResponse.classifications[0].intent.includes("book")
            ? responseArray.slice(0, 4)
            : botResponse.answer;
          resultIntent = botResponse.classifications[0].intent.includes("book")
            ? "book"
            : "hello";
        }
        res.status(200).json({
          status: "success",
          message: `response200`,
          data: {
            message: resultMessage,
            intent: resultIntent,
          },
        });
      } else {
        res.status(400).json({
          status: "failed",
          message: `response400`,
          data: [{ message: "I don't understand." }],
        });
      }
    });
  }

  getRouter(): Router {
    this.getRoute();
    return this.router;
  }
}
