"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Required External Modules
 */
require("reflect-metadata");
const dotenv = __importStar(require("dotenv"));
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const bodyParser = require("body-parser");
const chatbot_service_1 = require("./chatbot/chatbot.service");
const error_middleware_1 = require("./middlewares/error.middleware");
const not_found_middleware_1 = require("./middlewares/not-found.middleware");
const mongodb_connector_1 = require("./mongodb.connector");
const book_controller_1 = require("./controllers/book.controller");
const order_controller_1 = require("./controllers/order.controller");
const coupon_controller_1 = require("./controllers/coupon.controller");
const user_controller_1 = require("./controllers/user.controller");
const wishlist_controller_1 = require("./controllers/wishlist.controller");
const chatbot_controller_1 = require("./chatbot/chatbot.controller");
const stripe_controller_1 = require("./controllers/stripe.controller");
dotenv.config();
/**
 * App Variables
 */
if (!process.env.PORT) {
    process.exit(1);
}
const PORT = parseInt(process.env.PORT, 10);
const app = (0, express_1.default)();
/**
 *  App Configuration
 */
app.use((0, cors_1.default)());
app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));
app.use(express_1.default.json());
const connector = new mongodb_connector_1.MongoDBConnectorImpl();
connector.connect();
const chatbotService = new chatbot_service_1.ChatbotService();
app.use("/create-payment-intent", new stripe_controller_1.StripeController().getRouter());
app.use("/book", new book_controller_1.BookController(connector, chatbotService).getRouter());
app.use("/chatbot", new chatbot_controller_1.ChatbotController(chatbotService).getRouter());
app.use("/coupon", new coupon_controller_1.CouponController(connector).getRouter());
app.use("/order", new order_controller_1.OrderController(connector).getRouter());
app.use("/user", new user_controller_1.UserController(connector).getRouter());
app.use("/wishlist", new wishlist_controller_1.WishlistController(connector).getRouter());
app.use(error_middleware_1.errorHandler);
app.use(not_found_middleware_1.notFoundHandler);
/**
 * Server Activation
 */
app.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`);
});
