import { injectable } from "inversify";
import { ClientSession, Db, MongoClient, TransactionOptions } from "mongodb";
import { bookstoreAPIError, InternalServerError } from "./common/error.types";

export interface MongoDBConnector {
    getClient(): MongoClient
    connect(): Promise<void>
    getDatabase(): Db
    transaction<T>(handler: (session: ClientSession) => Promise<T>, options?: TransactionOptions): Promise<T>
}

@injectable()
export class MongoDBConnectorImpl implements MongoDBConnector {
    private client!: MongoClient

    constructor() { }

    async connect(): Promise<void> {
        if (!this.client){
            this.client = await MongoClient.connect('mongodb://localhost:27017');
            console.log("Connected to MongoDB");
        }
    }

    getClient(): MongoClient {
        if (!this.client) {
            throw InternalServerError({
                message: 'Failed to get MongoDB Client instance. We probably forgot to call or await for MongoDBConnector.connect()'
            });
        }
        return this.client;
    }

    getDatabase(): Db {
        const client = this.getClient();
        return client.db(process.env.DB_NAME);
    }

    async transaction<T>(handler: (session: ClientSession) => Promise<T>, options: TransactionOptions = {}): Promise<T> {
        const client = this.getClient();
        const session = client.startSession();

        try {
            let result

            await session.withTransaction(async () => {
                result = await handler(session);
            }, options);

            return result;
        } catch (e) {
            if (e instanceof bookstoreAPIError) {
                throw e;
            } else {
                throw InternalServerError({
                    message: 'Internal Server Error',
                    before: e
                });
            }
        } finally {
            await session.endSession();
        }
    }
}