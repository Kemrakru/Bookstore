/**
 * Required External Modules
 */
import "reflect-metadata";
import * as dotenv from "dotenv";
import express from "express";
import cors from "cors";
const bodyParser = require("body-parser");

import { ChatbotService } from "./chatbot/chatbot.service";
import { errorHandler } from "./middlewares/error.middleware";
import { notFoundHandler } from "./middlewares/not-found.middleware";
import { MongoDBConnectorImpl } from "./mongodb.connector";

import { BookController } from "./controllers/book.controller";
import { OrderController } from "./controllers/order.controller";
import { CouponController } from "./controllers/coupon.controller";
import { UserController } from "./controllers/user.controller";
import { WishlistController } from "./controllers/wishlist.controller";
import { ChatbotController } from "./chatbot/chatbot.controller";
import { StripeController } from "./controllers/stripe.controller";

dotenv.config();

/**
 * App Variables
 */

if (!process.env.PORT) {
  process.exit(1);
}

const PORT: number = parseInt(process.env.PORT as string, 10);

const app = express();

/**
 *  App Configuration
 */

app.use(cors());
app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));
app.use(express.json());

const connector: MongoDBConnectorImpl = new MongoDBConnectorImpl();
connector.connect();
const chatbotService: ChatbotService = new ChatbotService();

app.use("/create-payment-intent", new StripeController().getRouter());
app.use("/book", new BookController(connector, chatbotService).getRouter());
app.use("/chatbot", new ChatbotController(chatbotService).getRouter());
app.use("/coupon", new CouponController(connector).getRouter());
app.use("/order", new OrderController(connector).getRouter());
app.use("/user", new UserController(connector).getRouter());
app.use("/wishlist", new WishlistController(connector).getRouter());

app.use(errorHandler);
app.use(notFoundHandler);

/**
 * Server Activation
 */

app.listen(PORT, () => {
  console.log(`Listening on port ${PORT}`);
});
