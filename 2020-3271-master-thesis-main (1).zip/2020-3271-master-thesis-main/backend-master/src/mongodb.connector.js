"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MongoDBConnectorImpl = void 0;
const inversify_1 = require("inversify");
const mongodb_1 = require("mongodb");
const error_types_1 = require("./common/error.types");
let MongoDBConnectorImpl = class MongoDBConnectorImpl {
    constructor() { }
    async connect() {
        if (!this.client) {
            this.client = await mongodb_1.MongoClient.connect('mongodb://localhost:27017');
            console.log("Connected to MongoDB");
        }
    }
    getClient() {
        if (!this.client) {
            throw (0, error_types_1.InternalServerError)({
                message: 'Failed to get MongoDB Client instance. We probably forgot to call or await for MongoDBConnector.connect()'
            });
        }
        return this.client;
    }
    getDatabase() {
        const client = this.getClient();
        return client.db(process.env.DB_NAME);
    }
    async transaction(handler, options = {}) {
        const client = this.getClient();
        const session = client.startSession();
        try {
            let result;
            await session.withTransaction(async () => {
                result = await handler(session);
            }, options);
            return result;
        }
        catch (e) {
            if (e instanceof error_types_1.bookstoreAPIError) {
                throw e;
            }
            else {
                throw (0, error_types_1.InternalServerError)({
                    message: 'Internal Server Error',
                    before: e
                });
            }
        }
        finally {
            await session.endSession();
        }
    }
};
MongoDBConnectorImpl = __decorate([
    (0, inversify_1.injectable)()
], MongoDBConnectorImpl);
exports.MongoDBConnectorImpl = MongoDBConnectorImpl;
