"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateNew = exports.validatePatch = exports.validateId = exports.getValidatorId = exports.getUserValidatorPatch = exports.getUserValidatorNew = exports.getWishlistValidatorPatch = exports.getWishlistValidatorNew = exports.getOrderValidatorNew = exports.getCouponValidatorPatch = exports.getCouponValidatorNew = exports.getBookValidatorPatch = exports.getBookValidatorNew = void 0;
const jtd_1 = __importDefault(require("ajv/dist/jtd"));
const error_types_1 = require("./common/error.types");
const ajv = new jtd_1.default();
function getBookValidatorNew() {
    const NewBookSchema = {
        properties: {
            isbn: { type: "string" },
            title: { type: "string" },
            available: { type: "boolean" },
            amount: { type: "int32" },
            sold: { type: "int32" },
            cover: { type: "string" },
            authors: {
                elements: {
                    type: "string"
                }
            },
            categories: {
                elements: {
                    type: "string"
                }
            },
            coverType: { type: "string" },
            pages: { type: "int32" },
            pubDate: { type: "string" },
            publisher: { type: "string" },
            description: { type: "string" },
            language: { type: "string" },
            price: { type: "int32" },
            rating: { type: "string" },
            ratingsNum: { type: "string" },
        }
    };
    const validateNewBookSchema = ajv.compile(NewBookSchema);
    return validateNewBookSchema;
}
exports.getBookValidatorNew = getBookValidatorNew;
function getBookValidatorPatch() {
    const PatchBookSchema = {
        optionalProperties: {
            isbn: { type: "string" },
            title: { type: "string" },
            available: { type: "boolean" },
            amount: { type: "int32" },
            sold: { type: "int32" },
            cover: { type: "string" },
            authors: {
                elements: {
                    type: "string"
                }
            },
            categories: {
                elements: {
                    type: "string"
                }
            },
            coverType: { type: "string" },
            pages: { type: "int32" },
            pubDate: { type: "string" },
            publisher: { type: "string" },
            description: { type: "string" },
            language: { type: "string" },
            price: { type: "number" },
            rating: { type: "string" },
            ratingsNum: { type: "string" },
        }
    };
    const validatePatchBookSchema = ajv.compile(PatchBookSchema);
    return validatePatchBookSchema;
}
exports.getBookValidatorPatch = getBookValidatorPatch;
function getCouponValidatorNew() {
    const NewCouponSchema = {
        properties: {
            categories: {
                elements: {
                    type: "string"
                }
            },
            dateTo: { type: "string" },
            name: { type: "string" },
            code: { type: "string" },
            amount: { type: "int32" },
            banner: { type: "string" },
            discount: { type: "int32" }
        }
    };
    const validateNewCouponSchema = ajv.compile(NewCouponSchema);
    return validateNewCouponSchema;
}
exports.getCouponValidatorNew = getCouponValidatorNew;
function getCouponValidatorPatch() {
    const PatchCouponSchema = {
        optionalProperties: {
            categories: {
                elements: {
                    type: "string"
                }
            },
            dateTo: { type: "string" },
            name: { type: "string" },
            code: { type: "string" },
            amount: { type: "int32" },
            banner: { type: "string" },
            discount: { type: "int32" }
        }
    };
    const validatePatchCouponSchema = ajv.compile(PatchCouponSchema);
    return validatePatchCouponSchema;
}
exports.getCouponValidatorPatch = getCouponValidatorPatch;
function getOrderValidatorNew() {
    const NewOrderSchema = {
        properties: {
            books: {
                elements: {
                    properties: {
                        bookId: { type: "string" },
                        amount: { type: "int32" },
                    }
                }
            },
            timestamp: { type: "string" },
            price: { type: "int32" },
            paymentType: { type: "string" },
            couponId: { type: "string" },
            couponCode: { type: "string" },
            userInfo: {
                properties: {
                    email: { type: "string" },
                    fullname: { type: "string" },
                    address: { type: "string" },
                    town: { type: "string" },
                    state: { type: "string" },
                    zip: { type: "string" },
                    phone: { type: "string" },
                    country: { type: "string" }
                }
            },
            sentDate: { type: "string" }
        },
        optionalProperties: {
            userId: { type: "string" }
        }
    };
    const validateNewOrderSchema = ajv.compile(NewOrderSchema);
    return validateNewOrderSchema;
}
exports.getOrderValidatorNew = getOrderValidatorNew;
function getWishlistValidatorNew() {
    const NewWishlistSchema = {
        properties: {
            name: { type: "string" },
            books: {
                elements: {
                    properties: {
                        title: { type: "string" },
                        available: { type: "boolean" },
                        amount: { type: "int32" },
                        cover: { type: "string" },
                        authors: {
                            elements: {
                                type: "string"
                            }
                        },
                        price: { type: "int32" }
                    }
                }
            },
            default: { type: "boolean" },
            userId: { type: "string" },
        }
    };
    const validateNewWishlistSchema = ajv.compile(NewWishlistSchema);
    return validateNewWishlistSchema;
}
exports.getWishlistValidatorNew = getWishlistValidatorNew;
function getWishlistValidatorPatch() {
    const PatchWishlistSchema = {
        optionalProperties: {
            name: { type: "string" },
            books: {
                elements: {
                    properties: {
                        title: { type: "string" },
                        available: { type: "boolean" },
                        amount: { type: "int32" },
                        cover: { type: "string" },
                        authors: {
                            elements: {
                                type: "string"
                            }
                        },
                        price: { type: "int32" }
                    }
                }
            },
            default: { type: "boolean" },
            userId: { type: "string" },
        }
    };
    const validatePatchWishlistSchema = ajv.compile(PatchWishlistSchema);
    return validatePatchWishlistSchema;
}
exports.getWishlistValidatorPatch = getWishlistValidatorPatch;
function getUserValidatorNew() {
    const NewUserSchema = {
        properties: {
            name: { type: "string" },
            email: { type: "string" },
            password: { type: "string" },
            phone: { type: "string" },
            fullname: { type: "string" },
            address: { type: "string" },
            town: { type: "string" },
            zip: { type: "string" },
            country: { type: "string" },
            type: { type: "string" }
        },
        optionalProperties: {
            state: { type: "string" }
        }
    };
    const validateNewUserSchema = ajv.compile(NewUserSchema);
    return validateNewUserSchema;
}
exports.getUserValidatorNew = getUserValidatorNew;
function getUserValidatorPatch() {
    const PatchUserSchema = {
        optionalProperties: {
            name: { type: "string" },
            email: { type: "string" },
            password: { type: "string" },
            phone: { type: "string" },
            fullname: { type: "string" },
            address: { type: "string" },
            town: { type: "string" },
            zip: { type: "string" },
            country: { type: "string" },
            type: { type: "string" },
            state: { type: "string" }
        }
    };
    const validatePatchUserSchema = ajv.compile(PatchUserSchema);
    return validatePatchUserSchema;
}
exports.getUserValidatorPatch = getUserValidatorPatch;
function getValidatorId() {
    const idSchema = {
        properties: {
            id: { type: "string" }
        }
    };
    const validateIdSchema = ajv.compile(idSchema);
    return validateIdSchema;
}
exports.getValidatorId = getValidatorId;
function validateId(data) {
    const isValid = getValidatorId()(data);
    validate(isValid);
}
exports.validateId = validateId;
function validatePatch(data, type) {
    let isValid = false;
    switch (type) {
        case "book":
            isValid = getBookValidatorPatch()(data);
            break;
        case "coupon":
            isValid = getCouponValidatorPatch()(data);
            break;
        case "user":
            isValid = getUserValidatorPatch()(data);
            break;
        case "wishlist":
            isValid = getWishlistValidatorPatch()(data);
            break;
        default:
            break;
    }
    validate(isValid);
}
exports.validatePatch = validatePatch;
function validateNew(data, type) {
    let isValid = false;
    switch (type) {
        case "book":
            isValid = getBookValidatorNew()(data);
            break;
        case "coupon":
            isValid = getCouponValidatorNew()(data);
            break;
        case "order":
            isValid = getOrderValidatorNew()(data);
            break;
        case "user":
            isValid = getUserValidatorNew()(data);
            break;
        case "wishlist":
            isValid = getWishlistValidatorNew()(data);
            break;
        default:
            break;
    }
    validate(isValid);
}
exports.validateNew = validateNew;
function validate(isValid) {
    if (!isValid) {
        const error = getValidatorId().errors[0];
        throw (0, error_types_1.ValidationError)(`Property ${error.instancePath} ${error.message}`);
    }
}
