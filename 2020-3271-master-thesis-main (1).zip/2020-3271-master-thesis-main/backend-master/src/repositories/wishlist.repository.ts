import { injectable } from "inversify";
import { Wishlist } from '../models/wishlist.model';
import { MongoDBConnector } from "../mongodb.connector";
import { BaseRepository, BaseRepositoryImpl } from "./base.repository";

export interface WishlistRepository extends BaseRepository<Wishlist> { }
@injectable()
export class WishlistRepositoryImpl extends BaseRepositoryImpl<Wishlist> implements WishlistRepository {
    constructor(
        dbConnector: MongoDBConnector
    ) {
        super(dbConnector, 'wishlists');
    }
}