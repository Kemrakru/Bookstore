import { injectable } from "inversify";
import { Book } from '../models/book.model';
import { MongoDBConnector } from "../mongodb.connector";
import { BaseRepository, BaseRepositoryImpl } from "./base.repository";

export interface BookRepository extends BaseRepository<Book> { 
    bestselling(): Promise<Book[]>
}
@injectable()
export class BookRepositoryImpl extends BaseRepositoryImpl<Book> implements BookRepository {
    constructor(
        dbConnector: MongoDBConnector
    ) {
        super(dbConnector, 'books');
    }

    public async bestselling(): Promise<Book[]> {
        const collection = this.getCollection();
        return await collection.find<Book>({}).sort({'sold':-1}).limit(7).toArray()
    }
}