import { injectable } from "inversify";
import { Order } from '../models/order.model';
import { MongoDBConnector } from "../mongodb.connector";
import { BaseRepository, BaseRepositoryImpl } from "./base.repository";

export interface OrderRepository extends BaseRepository<Order> { }
@injectable()
export class OrderRepositoryImpl extends BaseRepositoryImpl<Order> implements OrderRepository {
    constructor(
        dbConnector: MongoDBConnector
    ) {
        super(dbConnector, 'orders');
    }
}