import { injectable, unmanaged } from "inversify";
import { Collection, DeleteOptions, DeleteResult, Filter, FindCursor, FindOptions, InsertOneOptions, UpdateFilter, UpdateOptions } from "mongodb";
import { MongoDBConnector } from "../mongodb.connector";


export interface BaseRepository<T> {
    findOne(query: any, options?: FindOptions): Promise<T>
    find(query: any, options?: FindOptions): Promise<T[]>
    findWithPaging(query: any, page: number, limit:number): Promise<T[]>
    insert(object: Partial<T>, options?: InsertOneOptions): Promise<T>;
    update(query: Filter<T>, update: UpdateFilter<T>, options?: UpdateOptions): Promise<void>;
    deleteMany(query: Filter<T>,options?:DeleteOptions): Promise<DeleteResult>;
    deleteOne(query: Filter<T>, options?: DeleteOptions): Promise<DeleteResult>;
    getCollection(): Collection;
}
@injectable()
export abstract class BaseRepositoryImpl<T> implements BaseRepository<T> {
    constructor(
        @unmanaged() private dbConnector: MongoDBConnector,
        @unmanaged() private collectionName: string
    ) { }

    async findOne(query: Filter<T>, options?: FindOptions): Promise<T> {
        const collection = this.getCollection();
        return collection.findOne<T>(query, options);
    }

    async find(query: Filter<T>, options?: FindOptions): Promise<T[]> {
        const collection = this.getCollection();
        return await collection.find<T>(query, options).toArray();
    }

    async findWithPaging(query: any, page: number, limit: number): Promise<T[]> {
        const collection = this.getCollection();
        return await collection.find<T>(query).toArray();
    }

    async insert(object: T, options?: InsertOneOptions): Promise<T> {
        const collection = this.getCollection();
        const result = await collection.insertOne(object, options);
        
        return {
            _id: result.insertedId,
            ...object
        }
    }

    async update(query: Filter<T>, update: UpdateFilter<T>, options?: UpdateOptions): Promise<void> {
        const collection = this.getCollection();
        await collection.updateOne(query, update, options);
    }

    async deleteMany(query: Filter<T>, options?: DeleteOptions): Promise<DeleteResult> {
        const collection = this.getCollection();
        return collection.deleteMany(query, options);
    }

    async deleteOne(query: Filter<T>, options?: DeleteOptions): Promise<DeleteResult> {
        const collection = this.getCollection();
        return collection.deleteOne(query, options);
    }

    getCollection(): Collection {
        const database = this.dbConnector.getDatabase()
        return database.collection(this.collectionName);
    }
}