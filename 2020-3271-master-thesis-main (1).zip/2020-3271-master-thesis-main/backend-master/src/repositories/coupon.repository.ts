import { injectable } from "inversify";
import { Coupon } from '../models/coupon.model';
import { MongoDBConnector } from "../mongodb.connector";
import { BaseRepository, BaseRepositoryImpl } from "./base.repository";

export interface CouponRepository extends BaseRepository<Coupon> { }
@injectable()
export class CouponRepositoryImpl extends BaseRepositoryImpl<Coupon> implements CouponRepository {
    constructor(
        dbConnector: MongoDBConnector
    ) {
        super(dbConnector, 'coupons');
    }
}