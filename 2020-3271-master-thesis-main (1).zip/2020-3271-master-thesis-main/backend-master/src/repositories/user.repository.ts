import { injectable } from "inversify";
import { User } from '../models/user.model';
import { MongoDBConnector } from "../mongodb.connector";
import { BaseRepository, BaseRepositoryImpl } from "./base.repository";

export interface UserRepository extends BaseRepository<User> { }
@injectable()
export class UserRepositoryImpl extends BaseRepositoryImpl<User> implements UserRepository {
    constructor(
        dbConnector: MongoDBConnector
    ) {
        super(dbConnector, 'users');
    }
}