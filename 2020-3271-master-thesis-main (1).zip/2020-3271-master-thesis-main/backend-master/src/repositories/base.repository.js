"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseRepositoryImpl = void 0;
const inversify_1 = require("inversify");
let BaseRepositoryImpl = class BaseRepositoryImpl {
    constructor(dbConnector, collectionName) {
        this.dbConnector = dbConnector;
        this.collectionName = collectionName;
    }
    async findOne(query, options) {
        const collection = this.getCollection();
        return collection.findOne(query, options);
    }
    async find(query, options) {
        const collection = this.getCollection();
        return await collection.find(query, options).toArray();
    }
    async findWithPaging(query, page, limit) {
        const collection = this.getCollection();
        return await collection.find(query).toArray();
    }
    async insert(object, options) {
        const collection = this.getCollection();
        const result = await collection.insertOne(object, options);
        return Object.assign({ _id: result.insertedId }, object);
    }
    async update(query, update, options) {
        const collection = this.getCollection();
        await collection.updateOne(query, update, options);
    }
    async deleteMany(query, options) {
        const collection = this.getCollection();
        return collection.deleteMany(query, options);
    }
    async deleteOne(query, options) {
        const collection = this.getCollection();
        return collection.deleteOne(query, options);
    }
    getCollection() {
        const database = this.dbConnector.getDatabase();
        return database.collection(this.collectionName);
    }
};
BaseRepositoryImpl = __decorate([
    (0, inversify_1.injectable)(),
    __param(0, (0, inversify_1.unmanaged)()),
    __param(1, (0, inversify_1.unmanaged)())
], BaseRepositoryImpl);
exports.BaseRepositoryImpl = BaseRepositoryImpl;
